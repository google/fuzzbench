rsync -r -v ./ tcache:~/frameshift_eval/fuzzers/aflplusplus_fs/AFLplusplus-fs
