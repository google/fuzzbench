#ifndef LOG_E
  #define LOG_E LOG_F
#endif
