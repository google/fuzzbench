# AFL++ standalone mutator

this is the AFL++ havoc mutator as a standalone mutator

just type `make` to build.

```
aflpp-standalone inputfile outputfile [splicefile]
```

