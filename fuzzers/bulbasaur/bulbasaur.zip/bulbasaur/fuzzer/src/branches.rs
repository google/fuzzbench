use crate::{depot::SeedInfo, executor::StatusType};
use crate::depot::Depot;
use crate::stats::LocalStats;
use bpfuzz_common::config::BRANCH_CONTEXT_CNT;
use bpfuzz_common::{config::TMP_MAP_SIZE, shm::SHM};
use bpfuzz_common::trace_data;
#[cfg(feature = "unstable")]
use std::intrinsics::unlikely;
use std::sync::RwLockReadGuard;
use std::{
    self,
    collections::HashMap,
    sync::{
        atomic::{AtomicUsize, Ordering},
        Arc, RwLock,
    },
};
use rand::rngs::ThreadRng;
use rand::Rng;
use num::integer::gcd;

#[derive(PartialEq, Eq, Debug, Display, Clone, Copy)]
pub enum BranchType {
    Cmp,
    ConstCmp,
    Switch,
    FCmp,
    Strcmp,
    ConstStrcmp,
    StrcmpNonTerm,
    ConstStrcmpNonTerm,
    RtnFunction,
}

// Lookup table that groups context-sensitive edges by hit count ranges.
// [1], [2], [3], [4, 7], [8, 15], [16, 31], [32, 127], [128, 255]
static EDGE_LOOKUP: [u8; 256] = [
    0, 1, 2, 4, 8, 8, 8, 8, 16, 16, 16, 16, 16, 16, 16, 16, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32,
    32, 32, 32, 32, 32, 32, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64,
    64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64,
    64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64,
    64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64,
    64, 64, 64, 64, 64, 64, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128,
    128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128,
    128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128,
    128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128,
    128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128,
    128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128,
    128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 128,
];

// Lookup table that groups context-sensitive branches by hit count ranges.
// [1], [2], [3], [4, 6], [7, 12], [13, 20], [21, 35], [36, 63]
static BRANCH_LOOKUP: [u8; 64] = [
    0, // 0
    1, // 1
    2, // 2
    3, // 3
    4, 4, 4, // 4-6
    5, 5, 5, 5, 5, 5, // 7-12
    6, 6, 6, 6, 6, 6, 6, 6, // 13-20
    7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, // 21-35
    8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8 // 36-63
];

#[derive(Debug, Clone)]
pub struct MapSizeData {
    pub real_map_size: usize,
    pub used_map_size: usize,
    pub real_branch_map_size: usize,
    pub used_branch_map_size: usize
}

impl MapSizeData {
    pub fn new(real_map_size: usize, used_map_size: usize, real_branch_map_size: usize, used_branch_map_size: usize) -> Self {
        Self {
            real_map_size,
            used_map_size,
            real_branch_map_size,
            used_branch_map_size,
        }
    }
}

pub struct GlobalBranches {
    // We split the global bitmap into n chunks, each protected by its own RwLock.
    virgin_branches: Vec<RwLock<Box<[u8]>>>,
    tmouts_branches: Vec<RwLock<Box<[u8]>>>,
    crashes_branches: Vec<RwLock<Box<[u8]>>>,
    full_virgin_branches: Vec<RwLock<Box<[u8]>>>,
    edge_favor_map: Vec<RwLock<Box<[[SeedInfo; BRANCH_CONTEXT_CNT]]>>>,

    global_branch_cov_map: RwLock<Box<[u8]>>,

    branch_favor_map: Vec<RwLock<Box<[[SeedInfo; BRANCH_CONTEXT_CNT]]>>>,
    fast_map_size_data: MapSizeData,
    full_map_size_data: MapSizeData,
    trace_map_size_data: MapSizeData,
    // global states.
    cov_edges: AtomicUsize,
    cov_branches: AtomicUsize,
    frontier_branches: AtomicUsize,

    thread_num: usize,
    // These vecs help to iterate through the splited bitmaps.
    start_pos: Vec<usize>,
    end_pos: Vec<usize>,
    full_start_pos: Vec<usize>,
    full_end_pos: Vec<usize>,
    branch_start_pos: Vec<usize>,
    branch_end_pos: Vec<usize>,

    edge_to_pred_branch_dict: HashMap<usize, usize>,
    branch_type_dict: HashMap<usize, BranchType>, 
    trace_branch_type_dict: HashMap<usize, BranchType>,
    branch_boundary: Box<[AtomicUsize]>,
}

impl GlobalBranches {

    pub fn new(n: usize, fast_map_size_data: MapSizeData, full_map_size_data: MapSizeData, trace_map_size_data: MapSizeData,
            edge_to_pred_branch_dict: HashMap<usize, usize>, 
            branch_type_dict: HashMap<usize, BranchType>, 
            trace_branch_type_dict: HashMap<usize, BranchType>
    ) -> Self {

        assert!(n > 0, "n must be greater than 0");

        let (virgin_branches, start_pos, end_pos) = Self::create_chunks::<u8>(255, fast_map_size_data.used_map_size, n);
        let (tmouts_branches, _, _) = Self::create_chunks::<u8>(255, fast_map_size_data.used_map_size, n);
        let (crashes_branches, _, _) = Self::create_chunks::<u8>(255, fast_map_size_data.used_map_size, n);
        let (edge_favor_map, _, _) = Self::create_chunks::<[SeedInfo; 8]>([SeedInfo::default(); 8], fast_map_size_data.used_map_size, n);
        
        let (full_virgin_branches, full_start_pos, full_end_pos) = Self::create_chunks::<u8>(255, full_map_size_data.used_map_size, n);
        
        let (branch_favor_map, branch_start_pos, branch_end_pos) = Self::create_chunks::<[SeedInfo; BRANCH_CONTEXT_CNT]>([SeedInfo::default(); BRANCH_CONTEXT_CNT], fast_map_size_data.used_branch_map_size, n);

        let branch_boundary = (0..fast_map_size_data.real_branch_map_size).map(|_| AtomicUsize::new(0))
                                                                         .collect::<Vec<_>>()
                                                                         .into_boxed_slice();
        
        for (_, branch) in &edge_to_pred_branch_dict {
            let old_value = branch_boundary[*branch].fetch_add(1, Ordering::Release);
            assert!(old_value <= 1, "branch_boundary[{}] exceeded 1", *branch);
        }

        for (branch, branch_type) in &branch_type_dict {
            if *branch_type == BranchType::StrcmpNonTerm || *branch_type == BranchType::ConstStrcmpNonTerm {
                let old_value = branch_boundary[*branch].fetch_add(1, Ordering::Release);
                assert!(old_value == 0, "strcmp_non_term branch_boundary[{}] exceeded 0", *branch);
            }
            assert!(*branch_type != BranchType::RtnFunction);
        }

        for (_, branch_type) in &trace_branch_type_dict {
            assert!(*branch_type != BranchType::RtnFunction);
        }

        for idx in 1..full_map_size_data.real_branch_map_size {
            let value = branch_boundary[idx].load(Ordering::Acquire);
            assert!(value != 0, "branch_boundary[{}] is 0.", idx)
        }

        Self {
            virgin_branches,
            tmouts_branches,
            crashes_branches,
            full_virgin_branches,
            edge_favor_map,
            global_branch_cov_map: RwLock::new(vec![0; fast_map_size_data.used_branch_map_size / 8].into_boxed_slice()),
            branch_favor_map,
            fast_map_size_data,
            full_map_size_data,
            trace_map_size_data,
            cov_edges: AtomicUsize::new(0),
            cov_branches: AtomicUsize::new(0),
            frontier_branches: AtomicUsize::new(0),
            thread_num: n,
            start_pos,
            end_pos,
            full_start_pos,
            full_end_pos,
            branch_start_pos,
            branch_end_pos,
            edge_to_pred_branch_dict,
            branch_type_dict,
            trace_branch_type_dict,
            branch_boundary,
        }
    }

    pub fn get_edge_stats(&self) -> (usize, usize, f32) {
        let cov_edges = self.cov_edges.load(Ordering::Relaxed);
        let percent = (cov_edges * 10000 / self.fast_map_size_data.real_map_size) as f32 / 100.0;
        (cov_edges, self.fast_map_size_data.real_map_size, percent)
    }

    pub fn get_branch_stats(&self) -> (usize, usize, f32) {
        let cov_branches = self.cov_branches.load(Ordering::Relaxed);
        let percent = (cov_branches * 10000 / self.fast_map_size_data.real_branch_map_size) as f32 / 100.0;
        (cov_branches, self.fast_map_size_data.real_branch_map_size, percent)
    }

    pub fn get_frontier_branches(&self) -> usize {
        self.frontier_branches.load(Ordering::Relaxed)
    }

    fn create_chunks<T: Clone>(
        fill_value: T,
        total_size: usize,
        chunk_num: usize,
    ) -> (Vec<RwLock<Box<[T]>>>, Vec<usize>, Vec<usize>) {
        let chunk_size = total_size / chunk_num;
        let extra = total_size % chunk_num;
    
        let mut current_pos: usize = 0;
        let mut start_pos = Vec::with_capacity(chunk_num);
        let mut end_pos = Vec::with_capacity(chunk_num);
        let chunks: Vec<RwLock<Box<[T]>>> = (0..chunk_num)
            .map(|i| {
                let size = if i < extra { chunk_size + 1 } else { chunk_size };
                start_pos.push(current_pos);
                current_pos += size;
                end_pos.push(current_pos - 1);
                RwLock::new(vec![fill_value.clone(); size].into_boxed_slice())
            })
            .collect();
    
        (chunks, start_pos, end_pos)
    }
}

pub struct Branches {
    global: Arc<GlobalBranches>,
    depot: Arc<Depot>,
    trace_map: SHM<u8>,         // Trace the coverage in fast target.
    full_trace_map: SHM<u8>,    // Trace the coverage in full target.
    taint_trace_map: SHM<u8>,   // Trace the coverage in trace target.
    frontier_branch_map: SHM<u16>, // Trace the branch match value in fast target.
    /* Shm in trace target */
    cmp_trace_map: SHM::<trace_data::CmpTrace>,

    steps: Vec<usize>,
    thread_num: usize,
    fast_map_size_data: MapSizeData,
    full_map_size_data: MapSizeData,
    trace_map_size_data: MapSizeData,
    insert_seed_flag: bool,
    seed_info: SeedInfo,
    rng: ThreadRng,
}

impl Branches {
    pub fn new(global: Arc<GlobalBranches>, depot: Arc<Depot>) -> Self {
        let thread_num = global.thread_num;
        let fast_map_size_data = global.fast_map_size_data.clone();
        let full_map_size_data = global.full_map_size_data.clone();
        let trace_map_size_data = global.trace_map_size_data.clone();
        // Use real_branch_map_size / 10 as max_frontier_cnt.
        // TODO: check if it is reasonable.
        let trace_map = SHM::<u8>::new(fast_map_size_data.used_map_size);
        let full_trace_map = SHM::<u8>::new(full_map_size_data.used_map_size);
        let taint_trace_map = SHM::<u8>::new(trace_map_size_data.used_map_size);
        let frontier_branch_map = SHM::<u16>::new(fast_map_size_data.used_branch_map_size);

        let cmp_trace_map: SHM<trace_data::CmpTrace> = SHM::<trace_data::CmpTrace>::new(trace_map_size_data.used_branch_map_size);

        // Compute all numbers that are coprime with `thread_num`, to be used as step sizes for iteration.
        let steps = if thread_num == 1 {
            vec![1usize]
        } else {
            (1..thread_num).filter(|&x| gcd(x, thread_num) == 1).collect()
        };

        Self { 
            global, 
            depot, 
            trace_map, 
            full_trace_map,
            taint_trace_map,
            frontier_branch_map,
            cmp_trace_map,
            steps, 
            thread_num,
            fast_map_size_data,
            full_map_size_data,
            trace_map_size_data,
            insert_seed_flag: false,
            seed_info: SeedInfo::default(),
            rng: rand::thread_rng(),
        }
    }

    pub fn clear_trace(&mut self) {
        self.trace_map.clear();
    }

    pub fn clear_full_trace(&mut self) {
        self.full_trace_map.clear();
    }

    pub fn clear_taint_trace(&mut self) {
        self.taint_trace_map.clear();
    }

    pub fn clear_frontier_branch(&mut self) {
        self.frontier_branch_map.clear();
    }

    pub fn clear_cmp_trace(&mut self) {
        self.cmp_trace_map.clear();
    }

    pub fn get_trace_id(&self) -> i32 {
        self.trace_map.get_id()
    }

    pub fn get_full_trace_id(&self) -> i32 {
        self.full_trace_map.get_id()
    }

    pub fn get_taint_trace_id(&self) -> i32 {
        self.taint_trace_map.get_id()
    }

    pub fn get_frontier_branch_id(&self) -> i32 {
        self.frontier_branch_map.get_id()
    }

    pub fn get_cmp_trace_id(&self) -> i32 {
        self.cmp_trace_map.get_id()
    }

    pub fn get_map_size(&self) -> usize {
        self.fast_map_size_data.used_map_size
    }

    pub fn get_full_map_size(&self) -> usize {
        self.full_map_size_data.used_map_size
    }

    pub fn get_branch_size(&self) -> usize {
        self.fast_map_size_data.used_branch_map_size
    }

    pub fn get_cmp_trace_copy(&self) -> Vec<trace_data::CmpTrace> {
        (*self.cmp_trace_map).to_vec()
    }

    pub fn get_trace_branch_type(&self, branch_id: usize) -> BranchType {
        if branch_id >= self.trace_map_size_data.real_branch_map_size && branch_id < self.trace_map_size_data.used_branch_map_size {
            // If branch_id is in virtual area, skip it. 
            return BranchType::Cmp;
        }
        *self.global.trace_branch_type_dict.get(&branch_id).unwrap()
    }

    // pub fn get_uncovered_branch_hash(&mut self) -> u64 {
    //     // Set the covered branches to 0. Then get hash.
    //     let read_guard = match self.global.global_branch_cov_map.read() {
    //         Ok(guard) => guard,
    //         Err(_) => {
    //             error!("global_branch_cov_map poisoned! Results may be incorrect.");
    //             panic!()
    //         }
    //     };
    //     let global_cov_data: &[u8] = &*read_guard;

    //     for i in 0..global_cov_data.len() {
    //         if global_cov_data[i] == 0 {
    //             continue;
    //         }
    //         for j in 0..8 {
    //             if (global_cov_data[i] & (1 << j)) != 0 {
    //                 self.frontier_branch_map[i * 8 + j] = 0;
    //             }
    //         }
    //     }
    //     self.frontier_branch_map.get_hash()
    // }

    // pub fn get_trace_map_hash(&self) -> u64 {
    //     self.trace_map.get_hash()
    // }
    
    // Return pairs of reached edges and their hit count id grouped by different chunks.
    // vec(chunk id, vec(edge id, hit count id))
    fn get_path(&self) -> Vec<Vec<(usize, u8)>> {
        let mut path: Vec<Vec<(usize, u8)>> = vec![Vec::new(); self.thread_num];
        let buf: &[u8] = &*self.trace_map;
        // Use u64 ptr to speed up!!!
        let buf_plus: &[u64] = unsafe {
            std::slice::from_raw_parts(buf.as_ptr() as *const u64, buf.len() / 8)
        };
        let mut map_p = 0;
        for (i, &v) in buf_plus.iter().enumerate() {
            if v > 0 {
                let base = i * 8;
                for j in 0..8 {
                    let idx = base + j;
                    while idx > self.global.end_pos[map_p] {
                        map_p += 1;
                    }

                    let new_val = buf[idx];
                    debug_assert!(map_p < self.thread_num, "map_p exceeds thread_num.");
                    if new_val > 0 {
                        // Global index -> Chunk index
                        path[map_p].push((idx - self.global.start_pos[map_p], EDGE_LOOKUP[new_val as usize]))
                    }
                }

            }
        }

        path
    }

    // Return pairs of reached edges and their hit count id 
    // from trace map of full target. (raw data!!)
    // vec(edge id, hit count id)
    pub fn get_raw_full_path(&self) -> Vec<(usize, u8)> {
        let mut raw_full_path = Vec::<(usize, u8)>::new();
        let buf: &[u8] = &*self.full_trace_map;
        // Use u64 ptr to speed up!!!
        let buf_plus: &[u64] = unsafe {
            std::slice::from_raw_parts(buf.as_ptr() as *const u64, buf.len() / 8)
        };
        for (i, &v) in buf_plus.iter().enumerate() {
            if v > 0 {
                let base = i * 8;
                for j in 0..8 {
                    let idx = base + j;

                    let new_val = buf[idx];
                    if new_val > 0 {
                        raw_full_path.push((idx, new_val as u8))
                    }
                }

            }
        }
        raw_full_path
    }

    // Return pairs of reached edges and their hit count id grouped by different chunks
    // from trace map of full target.
    // vec(edge id, hit count id)
    fn get_full_path(&self) -> Vec<Vec<(usize, u8)>> {
        let mut full_path: Vec<Vec<(usize, u8)>> = vec![Vec::new(); self.thread_num];
        let buf: &[u8] = &*self.full_trace_map;
        // Use u64 ptr to speed up!!!
        let buf_plus: &[u64] = unsafe {
            std::slice::from_raw_parts(buf.as_ptr() as *const u64, buf.len() / 8)
        };
        let mut map_p = 0;
        for (i, &v) in buf_plus.iter().enumerate() {
            if v > 0 {
                let base = i * 8;
                for j in 0..8 {
                    let idx = base + j;
                    while idx > self.global.full_end_pos[map_p] {
                        map_p += 1;
                    }

                    let new_val = buf[idx];
                    debug_assert!(map_p < self.thread_num, "map_p exceeds thread_num.");
                    if new_val > 0 {
                        // Global index -> Chunk index
                        full_path[map_p].push((idx - self.global.full_start_pos[map_p], EDGE_LOOKUP[new_val as usize]))
                    }
                }

            }
        }
        // debug!("count branch table: {}", path.len());
        full_path
    }

    // fn get_taint_path(&self) -> Vec<Vec<(usize, u8)>> {
    //     let mut taint_path: Vec<Vec<(usize, u8)>> = vec![Vec::new(); self.thread_num];
    //     let buf: &[u8] = &*self.taint_trace_map;
    //     // Use u64 ptr to speed up!!!
    //     let buf_plus: &[u64] = unsafe {
    //         std::slice::from_raw_parts(buf.as_ptr() as *const u64, buf.len() / 8)
    //     };
    //     let mut map_p = 0;
    //     for (i, &v) in buf_plus.iter().enumerate() {
    //         if v > 0 {
    //             let base = i * 8;
    //             for j in 0..8 {
    //                 let idx = base + j;
    //                 while idx > self.global.end_pos[map_p] {
    //                     map_p += 1;
    //                 }

    //                 let new_val = buf[idx];
    //                 debug_assert!(map_p < self.thread_num, "map_p exceeds thread_num.");
    //                 if new_val > 0 {
    //                     // Global index -> Chunk index
    //                     taint_path[map_p].push((idx - self.global.start_pos[map_p], EDGE_LOOKUP[new_val as usize]))
    //                 }
    //             }

    //         }
    //     }
    //     // debug!("count branch table: {}", path.len());
    //     taint_path
    // }
    
    // Update branches’ favored seeds based on branch match values.
    // Return true if there are higher match values.
    fn check_frontier_branch(&mut self, buf: &Vec<u8>) -> bool {

        // (usize, u16, u16) -> (position, context_id, match value)
        let mut frontier_branch_group: Vec<Vec<(usize, u16, u16)>> = vec![Vec::new(); self.thread_num];
        let mut frontier_branch_write_group: Vec<Vec<(usize, u16, u16)>> = vec![Vec::new(); self.thread_num];

        let mut covered_strcmp = Vec::new();

        {
            let cov_read_guard = match self.global.global_branch_cov_map.read() {
                Ok(guard) => guard,
                Err(_) => {
                    error!("global_branch_cov_map poisoned! Results may be incorrect.");
                    panic!()
                }
            };

            let cov_data: &[u8] = &*cov_read_guard;

            let map_buf: &[u16] = &*self.frontier_branch_map;
            // Use u64 ptr to speed up!!!
            let map_buf_plus: &[u64] = unsafe {
                std::slice::from_raw_parts(map_buf.as_ptr() as *const u64, map_buf.len() / 4)
            };
            let mut map_p = 0;

            for (i, &v) in map_buf_plus.iter().enumerate() {
                if v > 0 {
                    let base = i * 4;
                    for j in 0..4 {
                        let idx = base + j;
                        while idx > self.global.branch_end_pos[map_p] {
                            map_p += 1;
                        }

                        let new_val = map_buf[idx];
                        debug_assert!(map_p < self.thread_num, "map_p exceeds thread_num.");
                        if new_val > 0 {
                            // u16 = [xxxxxx] [xxxxxxxxxx]
                            // [xxxxxx] contains the hit count, which represents different path.
                            // [xxxxxxxxxx] is the match value.
                            let match_value = new_val & 0x3ff_u16;
                            assert!(match_value > 0, "match_value > 0!!");
                            let context_id = BRANCH_LOOKUP[((new_val >> 10) & 0x3f_u16) as usize] as u16;
                            assert!(context_id != 0, "context_id should not be 0.");
                            self.seed_info.match_value_sum += match_value as usize;

                            if (cov_data[idx / 8] & (1 << (idx % 8))) != 0 {
                                // If the branch is covered, skip it...
                                continue;
                            } 
                            frontier_branch_group[map_p].push((idx - self.global.branch_start_pos[map_p], context_id - 1, match_value))
                        }
                    }

                }
            }
        }

        // choose start chunk randomly.
        let start = self.rng.gen_range(0..self.thread_num);
        // choose prime step randomly.
        let step = self.steps[self.rng.gen_range(0..self.steps.len())];

        let mut write_flag = false;
        {
            // Read
            let mut visit_tags = vec![false; self.thread_num];
            let mut visited_count = 0;
    
            let mut idx = start;

            while visited_count < self.thread_num {
                if !visit_tags[idx] {
                    visit_tags[idx] = true;
                    visited_count += 1;

                    if frontier_branch_group[idx].len() != 0 {
                        if let Ok(read_guard) = self.global.branch_favor_map[idx].read() {
                            let data: &[[SeedInfo; BRANCH_CONTEXT_CNT]] = &*read_guard;
                            for elem in &frontier_branch_group[idx] {
                                if data[elem.0 as usize][elem.1 as usize].match_value < elem.2 {
                                    // If testcase has greater match value, we save it to frontier_branch_write_group and write it later.
                                    write_flag = true;
                                    frontier_branch_write_group[idx].push(*elem);
                                }
                            }
                        }
                    }
                    
                }

                idx = (idx + step) % self.thread_num;
            }
        }

        {
            // Write
            if write_flag {

                // Insert new seed if there are higher match values.
                self.insert_new_seed(StatusType::Normal, buf);

                let read_guard = match self.global.global_branch_cov_map.read() {
                    Ok(guard) => guard,
                    Err(_) => {
                        error!("global_branch_cov_map poisoned! Results may be incorrect.");
                        panic!()
                    }
                };

                let cov_data: &[u8] = &*read_guard;

                write_flag = false;          
                let mut visit_tags = vec![false; self.thread_num];
                let mut visited_count = 0;
                
                let mut idx = start;
                
                while visited_count < self.thread_num {
                    if !visit_tags[idx] {

                        visit_tags[idx] = true;
                        visited_count += 1;
                        if frontier_branch_write_group[idx].len() != 0 {
                            if let Ok(mut write_guard) = self.global.branch_favor_map[idx].write() {

                                let data  = &mut *write_guard;
                                for elem in &frontier_branch_write_group[idx] {
                                    // If the seed has greater match value, replace origin to it.

                                    if data[elem.0 as usize][elem.1 as usize].match_value < elem.2 {
                                        let real_br_id = elem.0 as usize + self.global.branch_start_pos[idx];
                                        // If the branch is covered, there is no need to insert.
                                        if (cov_data[real_br_id / 8] & (1 << (real_br_id % 8))) != 0 {
                                            continue;
                                        } 

                                        if elem.2 == 0x3ff {
                                            assert!(self.global.branch_type_dict[&real_br_id]== BranchType::StrcmpNonTerm
                                                    || self.global.branch_type_dict[&real_br_id]== BranchType::ConstStrcmpNonTerm);
                                            covered_strcmp.push(real_br_id);
                                        }

                                        // Check we insert or exchange
                                        let pre_seed_info = data[elem.0 as usize][elem.1 as usize];
                                        let mut insert_flag = false;
                                        if data[elem.0 as usize][elem.1 as usize].seed_id == 0 {
                                            insert_flag = true;
                                        }

                                        // Count the frontier branches...
                                        let mut new_frontier_branch = true;
                                        for branch_elem in &data[elem.0 as usize] {
                                            if branch_elem.seed_id != 0 {
                                                new_frontier_branch = false;
                                                break;
                                            }
                                        }
                                        if new_frontier_branch {
                                            self.global.frontier_branches.fetch_add(1, Ordering::Relaxed);
                                        }

                                        write_flag = true;
                                        data[elem.0 as usize][elem.1 as usize] = self.seed_info.clone();
                                        data[elem.0 as usize][elem.1 as usize].match_value = elem.2;

                                        if insert_flag  {
                                            // branch insert
                                            self.depot.branch_insert_favor_seed(self.seed_info, real_br_id, elem.1 as usize);
                                        } else {
                                            // branch exchange
                                            self.depot.branch_replace_favor_seed(pre_seed_info, self.seed_info, real_br_id, elem.1 as usize)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    idx = (idx + step) % self.thread_num;
                }
            }
        }

        if covered_strcmp.len() > 0 {
            // Update covered branches in depot...
            let mut write_guard = match self.global.global_branch_cov_map.write() {
                Ok(guard) => guard,
                Err(_) => {
                    error!("global_branch_cov_map poisoned! Results may be incorrect.");
                    panic!()
                }
            };

            let data: &mut [u8] = &mut *write_guard;
            covered_strcmp.sort();

            let mut idx = 0;
            let mut read_guard_option :Option<RwLockReadGuard<'_, Box<[[SeedInfo; BRANCH_CONTEXT_CNT]]>> > 
                = match self.global.branch_favor_map[idx].read() {
                    Ok(guard) => Some(guard),
                    Err(_) => {
                        error!("global_branch_cov_map poisoned! Results may be incorrect.");
                        panic!()
                    }
                };

            for branch in covered_strcmp {
                // Decrease branch boundary.
                let value = self.global.branch_boundary[branch].fetch_sub(1, Ordering::SeqCst);
                assert!(value == 1);

                // The branch has been already covered.
                assert!(data[branch / 8] & (1 << (branch % 8)) == 0);
                data[branch / 8] |= 1 << (branch % 8);
                self.global.cov_branches.fetch_add(1, Ordering::Relaxed);

                while branch > self.global.branch_end_pos[idx] {
                    idx += 1;
                    read_guard_option = match self.global.branch_favor_map[idx].read() {
                        Ok(guard) => Some(guard),
                        Err(_) => {
                            error!("global_branch_cov_map poisoned! Results may be incorrect.");
                            panic!()
                        }
                    };
                }
                assert!(branch >= self.global.branch_start_pos[idx]);

                if let Some(ref guard) = read_guard_option {
                    let mut seeds_info = Vec::new();

                    for s_info in guard[branch - self.global.branch_start_pos[idx]] {
                        if s_info.seed_id != 0 {
                            seeds_info.push(s_info);
                        }
                    }
                    if !seeds_info.is_empty() {
                        self.depot.branch_covered(&seeds_info, branch);
                        self.global.frontier_branches.fetch_sub(1, Ordering::Relaxed);
                    }
                }
            }
        }

        write_flag
    }

    // Decrease the branch boundary and tag the coverd branch according to new edges.
    pub fn update_branch_boundary(&mut self, 
                                    write_flag: bool, 
                                    full_path: Vec::<Vec::<(usize, u8)>>, 
                                    edge_to_write: Vec::<Vec::<(usize, u8)>>) {
        let mut new_edges = Vec::<usize>::new();

        // choose start chunk randomly.
        let start = self.rng.gen_range(0..self.thread_num);
        // choose prime step randomly.
        let step = self.steps[self.rng.gen_range(0..self.steps.len())];

        {
            // Write
            if write_flag {
                let mut visit_tags = vec![false; self.thread_num];
                let mut visited_count = 0;
                
                let mut idx = start;
                
                while visited_count < self.thread_num {
                    if !visit_tags[idx] {
                        visit_tags[idx] = true;
                        visited_count += 1;
                        if edge_to_write[idx].len() != 0 {

                            let mut write_guard = match self.global.full_virgin_branches[idx].write() {
                                Ok(guard) => guard,
                                Err(_) => {
                                    error!("gb_map mutex poisoned! Results may be incorrect.");
                                    panic!()
                                }
                            };

                            let data: &mut [u8] = &mut *write_guard;
                            for br in &edge_to_write[idx] {
                                let gb_v = data[br.0];
                                
                                if (br.1 & gb_v) > 0 {
                                    // Write truly.
                                    if gb_v == 255u8 {
                                        // new_edge stores complete index of all new edge.
                                        new_edges.push(self.global.full_start_pos[idx] + br.0);
                                    }
                                    data[br.0] = gb_v & (!br.1);
                                }
                            }
                        }
                    }

                    idx = (idx + step) % self.thread_num;
                }
            }
        }

        // It was originally assumed that if there is only one thread, this assertion would always hold.
        // But testing revealed that some branches may be variable...
        
        // TODO: Scrutinize it !!!!
        // assert!(new_edges.len() != 0);
        let mut covered_branchs = Vec::<usize>::new();

        {
            // We don’t actually need to read cov_map, but we must prevent race conditions.
            let _read_guard = match self.global.global_branch_cov_map.read() {
                Ok(guard) => guard,
                Err(_) => {
                    error!("global_branch_cov_map poisoned! Results may be incorrect.");
                    panic!()
                }
            };

            for &edge in &new_edges {
                if let Some(&branch) = self.global.edge_to_pred_branch_dict.get(&edge) {

                    let prev_value = self.global.branch_boundary[branch].load(Ordering::Acquire);
                    assert!(prev_value > 0, "element in branch_boundary is less than 0");
                    
                    let value = self.global.branch_boundary[branch].fetch_sub(1, Ordering::SeqCst);
                    if value == 1 {
                        // The branch is covered. We will write all together later.
                        covered_branchs.push(branch);
                    }
                }
            }
        }


        if covered_branchs.is_empty() {
            // If no write is needed, return.
            return;
        }

        // Update the covered branch in depot...
        let mut write_guard = match self.global.global_branch_cov_map.write() {
            Ok(guard) => guard,
            Err(_) => {
                error!("global_branch_cov_map poisoned! Results may be incorrect.");
                panic!()
            }
        };

        let data: &mut [u8] = &mut *write_guard;
        covered_branchs.sort();

        let mut idx = 0;
        let mut read_guard_option :Option<RwLockReadGuard<'_, Box<[[SeedInfo; BRANCH_CONTEXT_CNT]]>> > 
            = match self.global.branch_favor_map[idx].read() {
                Ok(guard) => Some(guard),
                Err(_) => {
                    error!("global_branch_cov_map poisoned! Results may be incorrect.");
                    panic!()
                }
            };

        for branch in covered_branchs {
            // Branch is covered.
            assert!(data[branch / 8] & (1 << (branch % 8)) == 0);
            data[branch / 8] |= 1 << (branch % 8);
            self.global.cov_branches.fetch_add(1, Ordering::Relaxed);

            while branch > self.global.branch_end_pos[idx] {
                idx += 1;
                read_guard_option = match self.global.branch_favor_map[idx].read() {
                    Ok(guard) => Some(guard),
                    Err(_) => {
                        error!("global_branch_cov_map poisoned! Results may be incorrect.");
                        panic!()
                    }
                };
            }
            assert!(branch >= self.global.branch_start_pos[idx]);

            if let Some(ref guard) = read_guard_option {
                let mut seeds_info = Vec::new();
                
                for s_info in guard[branch - self.global.branch_start_pos[idx]] {
                    if s_info.seed_id != 0 {
                        seeds_info.push(s_info);
                    }
                }
                if !seeds_info.is_empty() {
                    self.depot.branch_covered(&seeds_info, branch);
                    self.global.frontier_branches.fetch_sub(1, Ordering::Relaxed);
                }
            }
        }

    }

    pub fn insert_new_seed(&mut self, status: StatusType, buf: &Vec<u8>){
        // A trick, only insert one seed per has_new call.
        if !self.insert_seed_flag {
            self.insert_seed_flag = true;
            self.seed_info.seed_id = self.depot.save(status, buf);
        }
    }

    // Update edge_favor_map, we will insert or exchange edges' favor inputs.
    fn update_edge_favor_map(&mut self, path: &Vec<Vec<(usize, u8)>>, status: StatusType, buf: &Vec<u8>) {   
        let mut to_write = vec![Vec::new(); self.thread_num];

        // Choose start chunk randomly.
        let start = self.rng.gen_range(0..self.thread_num);
        // Choose prime step randomly.
        let step = self.steps[self.rng.gen_range(0..self.steps.len())];
        
        {
            // Read
            let mut idx = start;
            let mut visit_tags = vec![false; self.thread_num];
            let mut visited_count = 0;
            
            while visited_count < self.thread_num {
                if !visit_tags[idx] {
                    visit_tags[idx] = true;
                    visited_count += 1;

                    if path[idx].len() > 0 {
                        let read_guard = match self.global.edge_favor_map[idx].read() {
                            Ok(guard) => guard,
                            Err(_) => {
                                error!("gb_map mutex poisoned! Results may be incorrect.");
                                panic!()
                            }
                        };

                        let data = &*read_guard;

                        for br in &path[idx] {
                            let pos = br.1.trailing_zeros() as usize;
                            if data[br.0][pos].seed_id == 0 {
                                // insert...
                                to_write[idx].push(br);
                            } else {
                                let now_favor = (self.seed_info.len * self.seed_info.exec_time_us) as f64 / self.seed_info.match_value_sum as f64;
                                let pre_favor = (data[br.0][pos].len  * data[br.0][pos].exec_time_us) as f64 / data[br.0][pos].match_value_sum as f64;
                                if now_favor < pre_favor {
                                    // repleace...
                                    to_write[idx].push(br);
                                }
                            }

                        }                             
                    }


                }

                idx = (idx + step) % self.thread_num;
            }
        }

        {
            // Write
            let mut idx = start;
            let mut visit_tags = vec![false; self.thread_num];
            let mut visited_count = 0;
            
            while visited_count < self.thread_num {

                if !visit_tags[idx] {
                    visit_tags[idx] = true;
                    visited_count += 1;
                
                    if to_write[idx].len() > 0 {

                        // Insert new seed if there are higher match values.
                        self.insert_new_seed(StatusType::Normal, buf);

                        let mut write_guard = match self.global.edge_favor_map[idx].write() {
                            Ok(guard) => guard,
                            Err(_) => {
                                error!("gb_map mutex poisoned! Results may be incorrect.");
                                panic!()
                            }
                        };
                    
                        let data = &mut *write_guard;
                    
                        for br in &to_write[idx] {
                            let pos = br.1.trailing_zeros() as usize;
                            if data[br.0][pos].seed_id == 0 {
                                // insert...
                                self.depot.edge_insert_favor_seed(self.seed_info, br.0 + self.global.start_pos[idx], pos);
                                data[br.0][pos] = self.seed_info.clone();
                            } else {
                                let now_favor = (self.seed_info.len * self.seed_info.exec_time_us) as f64 / self.seed_info.match_value_sum as f64;
                                let pre_favor = (data[br.0][pos].len  * data[br.0][pos].exec_time_us) as f64 / data[br.0][pos].match_value_sum as f64;
                                if now_favor < pre_favor {
                                    // repleace...
                                    self.depot.edge_replace_favor_seed(data[br.0][pos], self.seed_info, br.0 + self.global.start_pos[idx], pos);
                                    data[br.0][pos] = self.seed_info.clone();
                                }
                            }
                            
                        }                             
                    }
                }
            
                idx = (idx + step) % self.thread_num;
            }
        }
    }

    pub fn has_new_full_edge(&mut self) -> (bool, Vec::<Vec::<(usize, u8)>>, Vec::<Vec::<(usize, u8)>>) {
        let full_path = self.get_full_path();
        let mut to_write = vec![Vec::new(); self.thread_num];
        let mut write_flag: bool = false;

        // choose start chunk randomly.
        let start = self.rng.gen_range(0..self.thread_num);
        // choose prime step randomly.
        let step = self.steps[self.rng.gen_range(0..self.steps.len())];

        {
            // Read
            let mut visit_tags = vec![false; self.thread_num];
            let mut visited_count = 0;
    
            let mut idx = start;
    
            while visited_count < self.thread_num {
                if !visit_tags[idx] {
                    visit_tags[idx] = true;
                    visited_count += 1;

                    if full_path[idx].len() != 0 {
                        
                        let read_guard = match self.global.full_virgin_branches[idx].read() {
                            Ok(guard) => guard,
                            Err(_) => {
                                error!("gb_map mutex poisoned! Results may be incorrect.");
                                panic!()
                            }
                        };

                        let data: &[u8] = &*read_guard;
                        for br in &full_path[idx] {
                            let gb_v = data[br.0];
                            
                            if (br.1 & gb_v) > 0 {
                                write_flag = true;
                                to_write[idx].push((br.0, br.1));
                            }
                        }
                    }
                    
                }

                idx = (idx + step) % self.thread_num;
            }
        }

        (write_flag, full_path, to_write)
    }

    // Check if the current input has new edges.
    pub fn has_new_edge(&mut self, status: StatusType, seed_info: SeedInfo) -> (bool, Vec::<Vec::<(usize, u8)>>, Vec::<Vec::<(usize, u8)>>) {
        // At most one seed is inserted into the depot per has_new call.
        self.insert_seed_flag = false;
        self.seed_info = seed_info;

        let gb_map = match status {
            StatusType::Normal => &self.global.virgin_branches,
            StatusType::Timeout => &self.global.tmouts_branches,
            StatusType::Crash => &self.global.crashes_branches,
            _ => {
                return (false, Vec::new(), Vec::new())
            },
        };
        let path = self.get_path();
        let edge_num: usize = path.iter().map(|sub_vec| sub_vec.len()).sum();
        self.seed_info.edge_num = edge_num;

        let thread_num = self.thread_num;

        let mut to_write = vec![Vec::new(); thread_num];
        let mut write_flag = false;

        // choose start chunk randomly.
        let start = self.rng.gen_range(0..thread_num);
        // choose prime step randomly.
        let step = self.steps[self.rng.gen_range(0..self.steps.len())];

        {
            // Read
            let mut visit_tags = vec![false; thread_num];
            let mut visited_count = 0;
    
            let mut idx = start;
    
            while visited_count < thread_num {
                if !visit_tags[idx] {
                    visit_tags[idx] = true;
                    visited_count += 1;

                    if path[idx].len() != 0 {
                        
                        let read_guard = match gb_map[idx].read() {
                            Ok(guard) => guard,
                            Err(_) => {
                                error!("gb_map mutex poisoned! Results may be incorrect.");
                                panic!()
                            }
                        };

                        let data: &[u8] = &*read_guard;
                        for br in &path[idx] {
                            let gb_v = data[br.0];
                            
                            if (br.1 & gb_v) > 0 {
                                write_flag = true;
                                to_write[idx].push((br.0, br.1));
                            }
                        }
                    }
                    
                }

                idx = (idx + step) % thread_num;
            }
        }
        (write_flag, path, to_write)
    }

    // If has new edge, we will calibrate the case to check variable edges.
    pub fn calibrate_edge(&mut self, first_path: &mut Vec::<Vec::<(usize, u8)>>, edge_to_write: &mut Vec::<Vec::<(usize, u8)>>, is_full: bool) -> bool {
        let path = if is_full {
            self.get_full_path()
        } else {
            self.get_path()
        };

        let mut is_variable = false;
        for part_id in 0..first_path.len() {

            // If the part of path is empty, we ignore all edges in first_path and edge_to_write.
            if path[part_id].len() == 0 && first_path[part_id].len() != 0 {
                is_variable = true;
                for edge in &mut first_path[part_id] {
                    edge.1 = 0xff_u8;
                }
                for edge in &mut edge_to_write[part_id] {
                    edge.1 = 0xff_u8;
                }
                continue
            }

            let mut path_ptr = 0;
            let mut to_write_ptr = 0;
            let mut to_add = Vec::new();

            for edge in &mut first_path[part_id] {

                while path_ptr < path[part_id].len() && edge.0 > path[part_id][path_ptr].0 {
                    // The edge in path but not in first_path, we will add it to first_path and to_write to ignore it.
                    to_add.push((path[part_id][path_ptr].0, 0xff_u8));
                    is_variable = true;
                    path_ptr += 1;
                }

                if path_ptr < path[part_id].len() && edge.0 == path[part_id][path_ptr].0 {
                    // The edge is in both path and first_path, but not equal.
                    if edge.1 != path[part_id][path_ptr].1 {
                        is_variable = true;
                        // Set the edge to 0xff, we will ignore it.
                        edge.1 = 0xff_u8;
                        {
                            // Write to to_write.
                            while to_write_ptr < edge_to_write[part_id].len() 
                                && edge_to_write[part_id][to_write_ptr].0 < edge.0 {
                                to_write_ptr += 1;
                            }
                            if to_write_ptr < edge_to_write[part_id].len() 
                                && edge_to_write[part_id][to_write_ptr].0 == edge.0 {
                                edge_to_write[part_id][to_write_ptr].1 = 0xff_u8;
                            }
                        }

                    }
                    path_ptr += 1;
                } else {
                    // The edge in first_path is not in path.
                    is_variable = true;
                    edge.1 = 0xff_u8;
                    {
                        // Write to to_write.
                        while to_write_ptr < edge_to_write[part_id].len() 
                            && edge_to_write[part_id][to_write_ptr].0 < edge.0 {
                            to_write_ptr += 1;
                        }
                        if to_write_ptr < edge_to_write[part_id].len() 
                            && edge_to_write[part_id][to_write_ptr].0 == edge.0 {
                            edge_to_write[part_id][to_write_ptr].1 = 0xff_u8;
                        }
                    }
                }

            }

            #[cfg(debug_assertions)]
            for edge in &to_add {
                if first_path[part_id].iter().any(|e| e.0 == edge.0) {
                    panic!("Duplicate edge found with the same first element: {}", edge.0);
                }
            }

            for edge in &to_add {
                first_path[part_id].push(*edge);
                edge_to_write[part_id].push(*edge);
            }
            if to_add.len() > 0 {
                first_path[part_id].sort();
                edge_to_write[part_id].sort();
            }
            
        }
        is_variable
    }

    pub fn update_edges_and_branches(&mut self, 
                                        status: StatusType,
                                        buf: &Vec<u8>,
                                        local_stats: &mut LocalStats,
                                        mut write_flag: bool, path: Vec::<Vec::<(usize, u8)>>, 
                                        edge_to_write: Vec::<Vec::<(usize, u8)>>,
                                        sync_flag: bool) -> (bool, bool, usize, bool) {
        let gb_map = match status {
            StatusType::Normal => &self.global.virgin_branches,
            StatusType::Timeout => &self.global.tmouts_branches,
            StatusType::Crash => &self.global.crashes_branches,
            _ => {
                return (false, false, 0, false);
            },
        };
        
        let mut new_edges = Vec::<usize>::new();
        let mut num_new_edge = 0;
        let mut has_new_edge = false;

        // choose start chunk randomly.
        let start = self.rng.gen_range(0..self.thread_num);
        // choose prime step randomly.
        let step = self.steps[self.rng.gen_range(0..self.steps.len())];

        {
            // Write
            if write_flag {
                // There may be no write operation, so reset write_flag. 
                write_flag = false;
                
                let mut visit_tags = vec![false; self.thread_num];
                let mut visited_count = 0;
                
                let mut idx = start;
                
                while visited_count < self.thread_num {
                    if !visit_tags[idx] {
                        visit_tags[idx] = true;
                        visited_count += 1;
                        if edge_to_write[idx].len() != 0 {

                            let mut write_guard = match gb_map[idx].write() {
                                Ok(guard) => guard,
                                Err(_) => {
                                    error!("gb_map mutex poisoned! Results may be incorrect.");
                                    panic!()
                                }
                            };

                            let data: &mut [u8] = &mut *write_guard;
                            for br in &edge_to_write[idx] {
                                let gb_v = data[br.0];
                                
                                if (br.1 & gb_v) > 0 {
                                    // Write truly.
                                    if gb_v == 255u8 {
                                        num_new_edge += 1;
                                        // new_edge stores complete index of all new edge.
                                        new_edges.push(self.global.start_pos[idx] + br.0);
                                    }
                                    write_flag = true;
                                    // Find new path, insert seed.
                                    if !self.insert_seed_flag {
                                        self.insert_seed_flag = true;
                                        self.seed_info.seed_id = self.depot.save(status, buf);
                                    }
                                    data[br.0] = gb_v & (!br.1);
                                }
                            }
                        }
                    }

                    idx = (idx + step) % self.thread_num;
                }
            }
        }

        if num_new_edge > 0 {
            if status == StatusType::Normal {
                // Only count virgin branches
                self.global
                    .cov_edges
                    .fetch_add(num_new_edge, Ordering::Relaxed);
            }
            has_new_edge = true;
        }

        let mut has_higher_match = false;
        if status == StatusType::Normal {
            // check_frontier_branch must be before edge_favor_map update, since we calculate match_value_sum here.
            has_higher_match = self.check_frontier_branch(buf);
            // Update edge_favor_map, we will insert or exchange edges' favor inputs.
            self.update_edge_favor_map(&path, status, buf);
        }

        // record result, we insert all sync seeds.
        if self.insert_seed_flag || sync_flag {
            local_stats.find_new(&status);
        }

        if !write_flag {
            return (false, false, self.seed_info.edge_num, has_higher_match);
        }

        (true, has_new_edge, self.seed_info.edge_num, has_higher_match)
    }

}

impl std::fmt::Debug for Branches {
    fn fmt(&self, f: &mut std::fmt::Formatter) -> std::fmt::Result {
        write!(f, "")
    }
}

// Note: TmpBranches should only be used to get map size in binary.
// It should only be instantiated in `get_crucial_data_from_binary()` (executor.rs).
pub struct TmpBranches {
    trace_map: SHM<u8>,
    frontier_branch_map: SHM<u16>,
    map_size: usize,
}

impl TmpBranches {
    pub fn new() -> Self {
        Self {
            trace_map: SHM::<u8>::new(TMP_MAP_SIZE),
            frontier_branch_map: SHM::<u16>::new(TMP_MAP_SIZE), 
            map_size: TMP_MAP_SIZE,
        }
    }

    pub fn get_trace_id(&self) -> i32 {
        self.trace_map.get_id()
    }

    pub fn get_frontier_branch_id(&self) -> i32 {
        self.frontier_branch_map.get_id()
    }

    pub fn get_map_size(&self) -> usize {
        self.map_size
    }
}

