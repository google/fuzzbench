#![cfg_attr(feature = "unstable", feature(core_intrinsics))]

#[macro_use]
extern crate log;
#[macro_use]
extern crate derive_more;

mod branches;
mod depot;
pub mod executor;
mod search;
mod stats;
mod parse_raw_section;

mod fuzz_loop;
mod fuzz_main;
mod fuzz_type;
mod extras;

mod bind_cpu;
mod check_dep;
mod command;
mod tmpfs;

pub use crate::fuzz_main::fuzz_main;
