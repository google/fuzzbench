// Direct copy fuzzing and length fuzzing with branch parameters.

use super::*;
use bpfuzz_common::config;
use crate::fuzz_type::FuzzType;
use crate::depot::SeedInfo;

pub struct TaintFuzz {
    havoc_div: usize,
    run_ratio: usize,
}

impl TaintFuzz {
    pub fn new(havoc_div: usize) -> Self {
        Self {
            havoc_div,
            run_ratio: 0,
        }
    }

    pub fn run<T: Rng>(&mut self, handler: &mut SearchHandler, rng: &mut T) {

        self.run_ratio = handler.calculate_score();
        
        // Run Trace Target to acquire parameters.
        handler.executor.local_stats.register(FuzzType::TaintFuzz);
        let mut tmp_buf = handler.buf.clone();
        handler.execute_trace_and_load(&tmp_buf);
        
        handler.executor.update_log();

        // Len Fuzz
        handler.executor.local_stats.register(FuzzType::LenFuzz);
        self.len_fuzz(handler, &mut tmp_buf, rng);
        handler.executor.update_log();

        // Direct Copy Fuzz
        handler.executor.local_stats.register(FuzzType::DirectCopyFuzz);
        self.direct_copy_fuzz(handler, &mut tmp_buf, rng);
        handler.executor.update_log();

    }

    pub fn len_fuzz<T: Rng>(&mut self, handler: &mut SearchHandler, tmp_buf: &mut Vec<u8>, rng: &mut T) {
        assert_eq!(tmp_buf.len(), handler.buf.len());
        let seed_len = tmp_buf.len();

        let lens = handler.len_vec.clone();
        for len in lens {
            if len == 0 {
                continue;
            }
            if len < seed_len {
                /* Trim seed. */ 
                tmp_buf.resize(len, 0);
                handler.execute(tmp_buf, SeedInfo::default());
                // restore
                tmp_buf.extend_from_slice(&handler.buf[len..]);
            } else if len > seed_len {
                assert!(len <= seed_len * 2 && len < config::MAX_INPUT_LEN);

                /* Append random data. */ 
                let mut append = vec![0u8; len - seed_len];
                rng.fill_bytes(&mut append);
                tmp_buf.extend_from_slice(&append);
                handler.execute(tmp_buf, SeedInfo::default());
                // restore
                tmp_buf.resize(seed_len, 0);
            }
        }

        #[cfg(debug_assertions)]
        {
            assert_eq!(tmp_buf.len(), handler.buf.len());
            for i in 0..tmp_buf.len() {
                assert_eq!(tmp_buf[i], handler.buf[i])
            }
        }
    }

    pub fn direct_copy_fuzz<T: Rng>(&mut self, handler: &mut SearchHandler, input_buf: &mut Vec<u8>, rng: &mut T) {
        // let mut str_map: HashSet< (Vec<u8>, Vec<u8>) > = HashSet::new();

        let max_cmp = (config::MAX_DIRECT_COPY_TIMES * 
                                self.run_ratio / 
                                self.havoc_div) 
                                >> 8;
        if max_cmp == 0 {
            return;
        }

        if handler.cmp_taint_data.len() + handler.strcmp_taint_data.len() == 0 {
            return;
        }

        let mut is_replace = false;

        for _ in 0..max_cmp {
            let max_stacking = 1 << (1 + rng.gen_range(0..config::HAVOC_STACK_POW2));
            let mut tmp_buf = input_buf.clone();

            for _ in 0..max_stacking {

                let data_idx = rng.gen_range(0..handler.cmp_taint_data.len() + handler.strcmp_taint_data.len());

                if data_idx < handler.cmp_taint_data.len() {
                    let cmp_data = handler.cmp_taint_data[data_idx].clone();

                    let bytes0 = &cmp_data.0.to_le_bytes()[0..cmp_data.2];
                    let bytes1 = &cmp_data.1.to_le_bytes()[0..cmp_data.2];

                    let bytes0_vec = bytes0.to_vec();
                    let bytes1_vec = bytes1.to_vec();

                    if bytes0_vec == bytes1_vec {
                        continue;
                    }

                    if self.match_and_replace_input(handler, &mut tmp_buf, &bytes0_vec, &bytes1_vec, rng) {
                        is_replace = true;
                    }
                } else {
                    let strcmp_data = handler.strcmp_taint_data[data_idx - handler.cmp_taint_data.len()].clone();

                    if self.match_and_replace_input(handler, &mut tmp_buf, &strcmp_data.0, &strcmp_data.1, rng) {
                        is_replace = true;
                    }
                }
            }
            
            // If the seed was successfully replaced, execute it.
            if is_replace {
                handler.execute(&tmp_buf, SeedInfo::default());
            }
        }
        
    }

    fn reversed(vec: &Vec<u8>) -> Vec<u8> {
        let mut v = vec.clone();
        v.reverse();
        v
    }


    // Find and replace a parameter in the input if matched.
    fn match_and_replace_input<T: Rng>(
        &mut self,
        handler: &mut SearchHandler,
        tmp_buf: &mut Vec<u8>,
        op1_substr: &Vec<u8>,
        op2_substr: &Vec<u8>,
        rng: &mut T,
    ) -> bool {
        let mut is_replace = false;

        let max_len = op1_substr.len().max(op2_substr.len());
        if tmp_buf.len() < max_len {
            return is_replace;
        }
    
        let mut pos = rng.gen_range(0..=tmp_buf.len() - max_len);
        let rev_op1 = Self::reversed(op1_substr);
        let rev_op2 = Self::reversed(op2_substr);
    
        while pos + max_len <= tmp_buf.len() {
            if &tmp_buf[pos..pos + op1_substr.len()] == op1_substr.as_slice() {
                tmp_buf.splice(pos..pos + op1_substr.len(), op2_substr.clone());
                is_replace = true;
                break;
            } else if &tmp_buf[pos..pos + op2_substr.len()] == op2_substr.as_slice() {
                tmp_buf.splice(pos..pos + op2_substr.len(), op1_substr.clone());
                is_replace = true;
                break;
            } else if &tmp_buf[pos..pos + op1_substr.len()] == rev_op1.as_slice() {
                tmp_buf.splice(pos..pos + op1_substr.len(), rev_op2.clone());
                is_replace = true;
                break;
            } else if &tmp_buf[pos..pos + op2_substr.len()] == rev_op2.as_slice() {
                tmp_buf.splice(pos..pos + op2_substr.len(), rev_op1.clone());
                is_replace = true;
                break;
            }
            pos += 1;
        }

        is_replace
    }

}