use std::{env, fs::File, io::prelude::*, mem, path::Path};
use std::{io::{BufRead, BufReader}, thread::sleep, time::Duration};

#[cfg(target_os = "linux")]
fn get_info_from_status(p: &Path) -> Option<usize> {
    let mut f = if let Ok(f) = File::open(p) {
        f
    } else {
        return None;
    };

    let mut buffer = String::new();
    f.read_to_string(&mut buffer).unwrap();

    let has_vm = buffer.contains("VmSize:");
    if !has_vm {
        // kernel tasks.
        return None;
    }

    if let Some(off) = buffer.find("Cpus_allowed_list:\t") {
        let off = off + 19;
        let mut sub = &buffer[off..];
        if let Some(end_off) = sub.find("\n") {
            sub = &sub[..end_off];
        }
        if sub.contains("-") || sub.contains(",") {
            return None;
        }
        if let Ok(cpuid) = sub.parse::<usize>() {
            return Some(cpuid);
        }
        None
    } else {
        None
    }
}

// #[cfg(not(target_os = "linux"))]
// pub fn find_free_cpus(_ask_num: usize) -> Vec<usize> {
//     vec![0; 1]
// }

// Find free CPUs.
// #[cfg(target_os = "linux")]
// pub fn find_free_cpus(ask_num: usize) -> Vec<usize> {
//     let mut free_cpus = vec![];

//     // Do not bind to CPU if DISABLE_CPU_BINDING_VAR is set.
//     if env::var(bpfuzz_common::defs::DISABLE_CPU_BINDING_VAR).is_ok() {
//         return free_cpus;
//     }

//     let proc_dir = Path::new("/proc");
//     let max_num = num_cpus::get();
//     let mut cpu_used = vec![false; max_num];
//     info!("Found {} cores.", max_num);
//     let entries = proc_dir.read_dir().unwrap();
//     for entry in entries {
//         if let Ok(entry) = entry {
//             let file_name = entry.file_name().into_string();
//             if let Ok(name) = file_name {
//                 // pid
//                 if let Ok(_) = name.parse::<u32>() {
//                     let path = entry.path();
//                     if let Some(cpuid) = get_info_from_status(&path.join("status")) {
//                         if cpuid < max_num {
//                             cpu_used[cpuid] = true;
//                         }
//                     }
//                 }
//             }
//         }
//     }

//     for i in 0..max_num {
//         if cpu_used[i] == false {
//             free_cpus.push(i);
//         }
//     }
//     info!("Free Cpus: {:?}", free_cpus);

//     if free_cpus.len() > ask_num {
//         free_cpus.truncate(ask_num);
//     }

//     free_cpus
// }

// Find CPUs whose usage is below 5%.
#[cfg(target_os = "linux")]
pub fn find_free_cpus(ask_num: usize) -> Vec<usize> {
    let mut free_cpus = vec![];

    // Do not bind to CPU if DISABLE_CPU_BINDING_VAR is set.
    if env::var(bpfuzz_common::defs::DISABLE_CPU_BINDING_VAR).is_ok() {
        return free_cpus;
    }

    let usage1 = read_cpu_stats();
    sleep(Duration::from_millis(100));
    let usage2 = read_cpu_stats();

    let mut cpu_usage: Vec<f64> = vec![];

    for (u1, u2) in usage1.iter().zip(usage2.iter()) {
        let delta_total = (u2.total - u1.total) as f64;
        let delta_idle = (u2.idle - u1.idle) as f64;
        let usage = if delta_total == 0.0 {
            0.0
        } else {
            1.0 - (delta_idle / delta_total)
        };
        cpu_usage.push(usage);
    }

    for (i, &u) in cpu_usage.iter().enumerate() {
        if u < 0.05 {
            free_cpus.push(i);
        }
    }

    info!("Free Cpus (usage < 5%): {:?}", free_cpus);

    if free_cpus.len() > ask_num {
        free_cpus.truncate(ask_num);
    }

    free_cpus
}

struct CpuStat {
    idle: u64,
    total: u64,
}

// Read cpu statistics from /proc/stat.
fn read_cpu_stats() -> Vec<CpuStat> {
    let file = File::open("/proc/stat").unwrap();
    let reader = BufReader::new(file);
    let mut stats = vec![];

    for line in reader.lines() {
        if let Ok(line) = line {
            if line.starts_with("cpu") && line.chars().nth(3).unwrap_or(' ').is_digit(10) {
                let parts: Vec<&str> = line.split_whitespace().collect();
                if parts.len() < 5 {
                    continue;
                }
                let idle: u64 = parts[4].parse().unwrap_or(0);
                let total: u64 = parts.iter()
                    .skip(1)
                    .take_while(|s| s.parse::<u64>().is_ok())
                    .map(|s| s.parse::<u64>().unwrap_or(0))
                    .sum();
                stats.push(CpuStat { idle, total });
            }
        }
    }

    stats
}

#[cfg(target_os = "linux")]
pub fn bind_thread_to_cpu_core(cid: usize) {
    unsafe {
        let mut c: libc::cpu_set_t = mem::zeroed();
        libc::CPU_ZERO(&mut c);
        libc::CPU_SET(cid, &mut c);
        if libc::sched_setaffinity(0, mem::size_of_val(&c), &c as *const libc::cpu_set_t) != 0 {
            panic!("sched_setaffinity failed");
        }
    }
}
