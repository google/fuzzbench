use super::*;
use crate::{executor::StatusType, extras::ExtraData};
use rand;
use std::collections::{HashMap, HashSet};
use std::{
    fs,
    io::prelude::*,
    path::{Path, PathBuf},
    sync::{
        atomic::{AtomicUsize, Ordering},
        Mutex,
    },
    time::{SystemTime, UNIX_EPOCH},
};
// https://crates.io/crates/priority-queue
use priority_queue::PriorityQueue;

/// `Depot` contains two seeds priority queues that decide the next seed to fuzz and some atomic flags.
pub struct Depot {
    // NOTE: Scrutinize the mutex to avoid race condition.
    pub branch_seed_priority: Mutex<PriorityQueue<SeedInfo, BranchPriority>>, // Contains seeds favored by branches.
    pub edge_seed_priority: Mutex<PriorityQueue<SeedInfo, BranchPriority>>, // Contains seeds favored by edges.
    pub branch_favor_seed_data: Mutex<HashMap<usize, HashSet<usize>> >, // Number of branches that favor each seed
    pub edge_favor_seed_data: Mutex<HashMap<usize, HashSet<usize>> >,   // Number of edges that favor each seed
    pub num_inputs: AtomicUsize,
    pub num_hangs: AtomicUsize,
    pub num_crashes: AtomicUsize,
    pub dirs: DepotDir,
    pub extras_data: Vec<ExtraData>,
}

impl Depot {
    pub fn new(in_dir: PathBuf, out_dir: &Path, extras_data: Vec<ExtraData>) -> Self {
        Self {
            branch_seed_priority: Mutex::new(PriorityQueue::new()),
            edge_seed_priority: Mutex::new(PriorityQueue::new()),
            branch_favor_seed_data: Mutex::new(HashMap::<usize, HashSet<usize> >::new()),
            edge_favor_seed_data: Mutex::new(HashMap::<usize, HashSet<usize> >::new()),
            num_inputs: AtomicUsize::new(0),
            num_hangs: AtomicUsize::new(0),
            num_crashes: AtomicUsize::new(0),
            dirs: DepotDir::new(in_dir, out_dir),
            extras_data,
        }
    }

    // Write input to directory.
    fn save_input(
        status: &StatusType,
        buf: &Vec<u8>,
        num: &AtomicUsize,
        dir: &Path,
    ) -> usize {
        let mut id = num.fetch_add(1, Ordering::Relaxed);
        // Seed id starts from 1.
        id += 1;
        trace!(
            "Find {} th new {:?} input.",
            id,
            status,
        );
        let new_path = get_file_name(dir, id);
        let mut f = fs::File::create(new_path.as_path()).expect("Could not save new input file.");
        f.write_all(buf)
            .expect("Could not write seed buffer to file.");
        f.flush().expect("Could not flush file I/O.");
        id
    }

    // Save the input to different directories based on the status type(normal, timeout, crash, etc.).
    pub fn save(&self, status: StatusType, buf: &Vec<u8>) -> usize {
        let id = match status {
            StatusType::Normal => Self::save_input(
                &status, 
                buf, 
                &self.num_inputs, 
                &self.dirs.inputs_dir
            ),
            StatusType::Timeout => Self::save_input(
                &status, 
                buf, 
                &self.num_hangs,
                &self.dirs.hangs_dir
            ),
            StatusType::Crash => Self::save_input(
                &status,
                buf,
                &self.num_crashes,
                &self.dirs.crashes_dir,
            ),
            _ => 0,
        };
        id
    }

    // Insert branch-favored seeds (i.e., those with higher branch match values) into the queue.
    pub fn branch_insert_favor_seed(&self, seed_info: SeedInfo, branch_id: usize, pos: usize) {
        assert!(pos < 8);

        let mut q = match self.branch_seed_priority.lock() {
            Ok(guard) => guard,
            Err(_) => {
                error!("branch_seed_priority mutex poisoned! Results may be incorrect.");
                panic!()
            }
        };

        #[cfg(debug_assertions)]
        {
            if self.branch_favor_seed_data.lock().unwrap().contains_key(&seed_info.seed_id) {
                assert!(!self.branch_favor_seed_data.lock().unwrap().get(&seed_info.seed_id).unwrap().contains(&branch_id))
            }
        }

        // Update branches favor numbers.
        self.branch_favor_seed_data
            .lock().unwrap()
            .entry(seed_info.seed_id)
            .or_insert_with(HashSet::new)
            .insert(branch_id);

        if q.get(&seed_info).is_none() {
            q.push(seed_info, BranchPriority::new(Self::current_timestamp()));
        }
    }

    // Replace the previously favored seed with a new one that has higher branch match values in the queue.
    pub fn branch_replace_favor_seed(&self, pre_seed_info: SeedInfo, now_seed_info: SeedInfo, branch_id: usize, pos: usize) {
        assert!(pos < 8);
        
        let mut q = match self.branch_seed_priority.lock() {
            Ok(guard) => guard,
            Err(_) => {
                error!("branch_seed_priority mutex poisoned! Results may be incorrect.");
                panic!()
            }
        };

        let mut data_guard = match self.branch_favor_seed_data.lock() {
            Ok(guard) => guard,
            Err(_) => {
                error!("branch_seed_priority mutex poisoned! Results may be incorrect.");
                panic!()
            }
        };

        if let Some(v) = data_guard.get_mut(&pre_seed_info.seed_id) {
            assert!(v.len() > 0, "the favor numbers of previous seed must be greater than 0");
            
            if !v.remove(&branch_id) {
                panic!("Branch id {} not found in branch favor data of seed {}", branch_id, pre_seed_info.seed_id);
            }

            if v.is_empty() {
                data_guard.remove(&pre_seed_info.seed_id);

                match q.remove(&pre_seed_info) {
                    Some((key, _)) => {
                        assert!(key == pre_seed_info);
                    },
                    _ => {
                        error!("the seed to be removed is not in branch_seed_priority.");
                        panic!()
                    }
                }
            }
        } else {
            panic!("seed_id {} not found in branch_favor_seed_data!", pre_seed_info.seed_id);
        }

        #[cfg(debug_assertions)]
        {
            if data_guard.contains_key(&now_seed_info.seed_id) {
                assert!(!data_guard.get(&now_seed_info.seed_id).unwrap().contains(&branch_id))
            }
        }

        // insert new seed.
        data_guard.entry(now_seed_info.seed_id)
            .or_insert_with(HashSet::new)
            .insert(branch_id);

        if q.get(&now_seed_info).is_none() {
            q.push(now_seed_info, BranchPriority::new(Self::current_timestamp()));
        }
    }

    // If the branch is covered, we will remove all seeds related to it.
    pub fn branch_covered(&self, seeds_info: &[SeedInfo], branch_id: usize) {
        let mut q = match self.branch_seed_priority.lock() {
            Ok(guard) => guard,
            Err(_) => {
                error!("branch_seed_priority mutex poisoned! Results may be incorrect.");
                panic!()
            }
        };

        let mut data_guard = match self.branch_favor_seed_data.lock() {
            Ok(guard) => guard,
            Err(_) => {
                error!("branch_favor_seed_data mutex poisoned! Results may be incorrect.");
                panic!()
            }
        };
        
        for s_info in seeds_info {
            if let Some(v) = data_guard.get_mut(&s_info.seed_id) {
                assert!(v.len() > 0, "the favor number of previous seed must be greater than 0");

                if !v.remove(&branch_id) {
                    panic!("Branch id {} not found in branch favor data of seed {}", branch_id, s_info.seed_id);
                }

                if v.is_empty() {
                    data_guard.remove(&s_info.seed_id);
    
                    match q.remove(&s_info) {
                        Some((key, _)) => {
                            assert!(key == *s_info);
                        },
                        _ => {
                            error!("the seed to be removed is not in branch_seed_priority.");
                            panic!()
                        }
                    }
                }
            } else {
                panic!("seed_id {} not found in branch_seed_favor_cnt!", s_info.seed_id);
            };
        }
    }

    // Insert edge-favored seeds (i.e., those with faster execution speed, shorter length, and higher branch match values) into the queue.
    pub fn edge_insert_favor_seed(&self, seed_info: SeedInfo, edge_id: usize, pos: usize) {
        assert!(pos < 8);

        let mut q = match self.edge_seed_priority.lock() {
            Ok(guard) => guard,
            Err(_) => {
                error!("edge_seed_priority mutex poisoned! Results may be incorrect.");
                panic!()
            }
        };

        #[cfg(debug_assertions)]
        {
            if self.edge_favor_seed_data.lock().unwrap().contains_key(&seed_info.seed_id) {
                assert!(!self.edge_favor_seed_data.lock().unwrap().get(&seed_info.seed_id).unwrap().contains(&edge_id))
            }
        }

        // Update favor number...
        self.edge_favor_seed_data
            .lock().unwrap()
            .entry(seed_info.seed_id)
            .or_insert_with(HashSet::new)
            .insert(edge_id);

        if q.get(&seed_info).is_none() {
            q.push(seed_info, BranchPriority::new(Self::current_timestamp()));
        }
    }

    // Replace the previously favored seed with a new one that has higher branch match values in the queue.
    pub fn edge_replace_favor_seed(&self, pre_seed_info: SeedInfo, now_seed_info: SeedInfo, edge_id: usize, pos: usize) {
        assert!(pos < 8);

        let mut q = match self.edge_seed_priority.lock() {
            Ok(guard) => guard,
            Err(_) => {
                error!("edge_seed_priority mutex poisoned! Results may be incorrect.");
                panic!()
            }
        };

        let mut data_guard = match self.edge_favor_seed_data.lock() {
            Ok(guard) => guard,
            Err(_) => {
                error!("edge_seed_priority mutex poisoned! Results may be incorrect.");
                panic!()
            }
        };

        if let Some(v) = data_guard.get_mut(&pre_seed_info.seed_id) {
            assert!(v.len() > 0, "the favor number of previous seed must be greater than 0");
            if !v.remove(&edge_id) {
                panic!("Edge id {} not found in edge favor data of seed {}", edge_id, pre_seed_info.seed_id);
            }

            if v.is_empty() {
                data_guard.remove(&pre_seed_info.seed_id);

                match q.remove(&pre_seed_info) {
                    Some((key, _)) => {
                        assert!(key == pre_seed_info);
                    },
                    _ => {
                        error!("the seed to be removed is not in edge_seed_priority.");
                        panic!()
                    }
                }
            }
        } else {
            panic!("seed_id {} not found in edge_seed_favor_cnt!", pre_seed_info.seed_id);
        }

        #[cfg(debug_assertions)]
        {
            if data_guard.contains_key(&now_seed_info.seed_id) {
                assert!(!data_guard.get(&now_seed_info.seed_id).unwrap().contains(&edge_id))
            }
        }

        // insert now seed.
        data_guard.entry(now_seed_info.seed_id)
            .or_insert_with(HashSet::new)
            .insert(edge_id);

        if q.get(&now_seed_info).is_none() {
            q.push(now_seed_info, BranchPriority::new(Self::current_timestamp()));
        }
    }
    
    // Return the next seed id to fuzz.
    pub fn get_top_seed(&self) -> SeedInfo {

        // Helper closure: get the front seed id from priority queue.
        let get_from_queue = |queue_mutex: &Mutex<PriorityQueue<SeedInfo, BranchPriority>>| {
            let mut q = queue_mutex.lock()
                .unwrap_or_else(|_| {
                    error!("priority queue mutex poisoned!");
                    panic!()
                });
    
            let (key, priority) = q.peek()
                .map(|(k, p)| (k.clone(), (*p).clone()))
                .expect("priority queue is empty.");
    
            let q_inc = priority.branch_inc();
            q.change_priority(&key, q_inc);
            key
        };
    
        // Get seed from either branch_seed_priority or edge_seed_priority randomly.
        let key = match rand::random::<bool>() {
            true => get_from_queue(&self.branch_seed_priority),
            false => get_from_queue(&self.edge_seed_priority),
        };

        key
    }

    pub fn empty(&self) -> bool {
        self.num_inputs.load(Ordering::Relaxed) == 0
    }

    pub fn next_random(&self) -> usize {
        rand::random::<usize>() % self.num_inputs.load(Ordering::Relaxed) + 1
    }

    pub fn get_input_buf(&self, id: usize) -> Vec<u8> {
        let path = get_file_name(&self.dirs.inputs_dir, id);
        read_from_file(&path)
    }

    pub fn get_branch_priority_num(&self) -> usize {
        self.branch_seed_priority.lock().unwrap().len()
    }

    pub fn get_bit_priority_num(&self) -> usize {
        self.edge_seed_priority.lock().unwrap().len()
    }

    fn current_timestamp() -> u64 {
        SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_secs()
    }

}