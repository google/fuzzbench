pub fn next_p2(val: usize) -> usize {
    if val <= 1 {
        return 1;
    }
    let mut ret = 1;
    while val > ret {
        ret <<= 1;
    }
    ret
}

