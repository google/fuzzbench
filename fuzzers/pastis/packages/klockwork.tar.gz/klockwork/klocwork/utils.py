from enum import Enum


class PastisVulnCategory(Enum):
    """
    Enum that represent the different categories of
    vulnerabilities for PASTIS.
    """
    BUFFER_OVERFLOW = 1
    INTEGER_OVERFLOW = 2
    OFF_BY_ONE = 3
    FORMAT_STRING = 4
    USE_AFTER_FREE = 5
    INVALID_MEMORY_ACCESS = 6


class PastisVulnKind(Enum):
    """
    Enum that represent the kind of an alert (whether
    a default or a vulnerability). That has to be
    determined manually.
    """
    DEFAULT = 1
    VULNERABILITY = 2


class KlocworkAlertType(Enum):
    """
    Enum that represent the different kind of alerts
    that Klocwork might yield.
    """
    # buffer overflow
    SV_STRBO_UNBOUND_COPY = 1
    SV_STRBO_BOUND_COPY_OVERFLOW = 2
    ABV_GENERAL = 3

    # integer overflow
    NUM_OVERFLOW = 10
    # PRECISION_LOSS = 11
    MISRA_ETYPE_CATEGORY_DIFFERENT_2012 = 11

    # uaf
    UFM_DEREF_MIGHT = 20
    UFM_FFM_MUST = 21
    UFM_FFM_MIGHT = 22

    # format string
    SV_TAINTED_FMTSTR = 30
    SV_FMTSTR_GENERIC = 31

    # invalid memory
    NPD_FUNC_MUST = 40
    NPD_CHECK_MIGHT = 41
    NPD_FUNC_MIGHT = 42
    NPD_CONST_CALL = 43

    # other alert types (unhandled)
    # MLK_MIGHT = 100
    # MLK_MUST = 101
    # SV_BANNED_RECOMMENDED_SPRINTF = 102
    # SV_BANNED_RECOMMENDED_STRLEN = 103
    # SV_BANNED_REQUIRED_COPY = 104
    # SV_BANNED_REQUIRED_SPRINTF = 105
    # FUNCRET_GEN = 106
    # INFINITE_LOOP_LOCAL = 107
    # RH_LEAK = 108
    # SV_TAINTED_CALL_BINOP = 109
    # SV_TAINTED_BINOP = 110


def alert_type_to_pastis_category(type: KlocworkAlertType) -> PastisVulnCategory:
    """
    Function to automatically assign a PASTIS vulnerability category according to
    the Klocwork alert type. As it is done automatically it cannot differentiate
    a buffer overflow from an off-by-one. Thus this function never returns off-by-one.

    :param type: Alert type to convert
    :return: PastisVulnCategory enum
    """
    K = KlocworkAlertType
    if type in [K.SV_STRBO_UNBOUND_COPY, K.SV_STRBO_BOUND_COPY_OVERFLOW, K.ABV_GENERAL]:
        return PastisVulnCategory.BUFFER_OVERFLOW
    elif type in [K.NUM_OVERFLOW, K.MISRA_ETYPE_CATEGORY_DIFFERENT_2012]:
        return PastisVulnCategory.INTEGER_OVERFLOW
    elif type in [K.UFM_DEREF_MIGHT, K.UFM_FFM_MUST, K.UFM_FFM_MIGHT]:
        return PastisVulnCategory.USE_AFTER_FREE
    elif type in [K.SV_TAINTED_FMTSTR, K.SV_FMTSTR_GENERIC]:
        return PastisVulnCategory.FORMAT_STRING
    elif type in [K.NPD_FUNC_MUST, K.NPD_CHECK_MIGHT, K.NPD_FUNC_MIGHT, K.NPD_CONST_CALL]:
        return PastisVulnCategory.INVALID_MEMORY_ACCESS
    else:
        assert False
