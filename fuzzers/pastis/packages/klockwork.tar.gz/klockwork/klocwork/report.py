# built-in imports
import logging
import json
from typing import Tuple, List, Optional, Union
from collections import namedtuple
from pathlib import Path
import csv

# local imports
from klocwork.utils import PastisVulnKind, PastisVulnCategory, KlocworkAlertType, alert_type_to_pastis_category
from klocwork.alert import KlocworkAlert

AlertStat = namedtuple('AlertStat', "checked total")


class KlocworkReport:
    """
    Class that manages a set of Klocwork alerts taken from a report
    exported in JSON (with the ``klocwork-report-to-json`` script).
    It also takes "pastis binding" JSON file to create a unified file.
    Then it can be used to update the status of each alerts when they
    happen to be covered and validated.
    """

    def __init__(self, in_file=None, bind_file=None):
        """
        Class constructor. Optionally takes the report JSON file
        and the pastis binding JSON file.

        :param in_file: Exported report JSON file path
        :param bind_file: Pastis binding JSON file path
        """
        self.alerts = {}  # Kid -> KlocworkAlert

        self._has_binding = False
        if in_file:
            self.parse_file(in_file)
        if bind_file and not self._has_binding:
            self.parse_alert_binding(bind_file)
            self._has_binding = True

    @property
    def counted_alerts(self):
        for a in self.alerts.values():
            if not a.ignored and a.has_pastis_binding:
                yield a

    @property
    def counted_alerts_count(self) -> int:
        return len(list(self.counted_alerts))

    def auto_bind(self) -> None:
        """
        Automatically bind all supported alerts. That method shall
        be called only if no binding is provided.
        :return: None
        """
        cur_id = 1
        for kid, alert in self.alerts.items():
            if alert.is_alert_type_supported():
                ptype = alert_type_to_pastis_category(alert.code)
                # create a binding entry (consider systematically the alert to be a vuln)
                alert.parse_pastis_binding({'id': cur_id, 'kid': kid, "category": ptype.name, "kind": PastisVulnKind.VULNERABILITY.name})
                self._has_binding = True
                cur_id += 1

    def get_alert(self, kid: Optional[int] = None, binding_id: Optional[int] = None) -> KlocworkAlert:
        """
        Get an alert from either its Klocwork ID or its binding id.

        :param kid: Klocwork identifier
        :param binding_id: Id given in bindings
        :return: Klocwork Alert
        """
        if kid and binding_id:
            raise Exception("Can't provide both a Klocwork ID and a binding ID")
        if kid:
            return self.alerts[kid]
        else:
            for a in self.counted_alerts:
                if a.id == binding_id:
                    return a
        raise IndexError(f"Identifier {kid}/{binding_id} not found")

    def all_alerts_validated(self) -> bool:
        """
        Checks whether or not all alerts considered, are covered and validated

        :return: True if all alerts are covered and vulns validated
        """
        for alert in self.counted_alerts:
            if not alert.covered:
                return False
            if alert.kind == PastisVulnKind.VULNERABILITY and not alert.validated:
                return False
        return True

    def all_alerts_validated_or_uncoverable(self) -> bool:
        """
        Checks whether or not all alerts considered, are covered validated or uncoverable

        :return: True if all alerts are covered and vulns validated or uncoverable
        """
        for alert in self.counted_alerts:
            if alert.uncoverable:
                continue
            if not alert.covered:
                return False
            if alert.kind == PastisVulnKind.VULNERABILITY and not alert.validated:
                return False
        return True

    def parse_file(self, in_file) -> None:
        """
        Parse the given export JSON file and fill the object
        with the different alerts encountered.

        :param in_file: Exported report JSON file path
        :return: None
        """
        with open(in_file) as f:
            data = json.load(f)
        for it in data:
            a = KlocworkAlert.from_json(it)
            self.alerts[a.kid] = a
            self._has_binding |= a.has_pastis_binding

    @staticmethod
    def from_json(data: Union[str, bytes]) -> 'KlocworkReport':
        """
        Parse the given string into a Klocwork report object.

        :param data: serialized report in JSON
        :return: KlocworkReport object
        """
        data = json.loads(data)
        report = KlocworkReport()
        for it in data:
            a = KlocworkAlert.from_json(it)
            report.alerts[a.kid] = a
            report._has_binding |= a.has_pastis_binding
        return report

    def has_binding(self):
        return self._has_binding

    def parse_alert_binding(self, in_file) -> None:
        """
        Parse the pastis binding JSON file to extend alerts
        info with pastis related data. This method has to be
        called after ``parse_file``.

        :param in_file: Pastis binding JSON file path
        :return: None
        """
        with open(in_file) as f:
            data = json.load(f)
        for it in data:
            self.alerts[it['kid']].parse_pastis_binding(it)

    def add_alert(self, alert: KlocworkAlert) -> None:
        """
        Add an alert in the report. This function is solely
        used by the report parser

        :param alert: Alert object to add in the report
        :return: None
        """
        if alert.kid in self.alerts:
            logging.warning(f"alert with kid:{alert.kid} already in report")
        self.alerts[alert.kid] = alert

    def to_list(self) -> List[dict]:
        """Convert the current report in a list of alert ready to be serialized"""
        return [x.to_json() for x in self.alerts.values()]

    def to_json(self) -> str:
        """
        Convert the current report in a list of alert ready to be serialized

        :return: report serialized in json
        """
        return json.dumps(self.to_list())

    def write(self, out_file=None) -> None:
        """
        Export the current state of the alerts within a JSON dictionnary.

        :param out_file: Output file path
        """
        with open(out_file, "w") as f:
            json.dump(self.to_list(), f, indent=2)

    def alerts_by_file(self, ignored=False) -> dict:
        """
        Return a view of the alerts such as keys are the
        different source files and values are alerts sorted
        by line numnber (increasing).

        :param ignored: True to include alerts that are not handled in the context of PASTIS
        :return: dictionnary where keys are file name strings and values alerts list
        """
        d = {}
        for alert in (x for x in self.alerts.values() if x.ignored == ignored):
            if alert.file in d:
                d[alert.file].append(alert)
            else:
                d[alert.file] = [alert]
        return {k: sorted(v, key=lambda x: x.line) for k, v in d.items()}

    def alerts_by_category(self) -> dict:
        """
        Return a view of the alerts indexed by the PASTIS vulnerability
        categories.

        :return: dict where keys are categories and values are alerts
        """
        d = {}
        for alert in (x for x in self.alerts.values() if not x.ignored):
            if alert.category in d:
                d[alert.category].append(alert)
            else:
                d[alert.category] = [alert]
        return d

    def get_stats(self) -> Tuple[AlertStat, AlertStat]:
        defaut = [0, 0]
        vulns = [0, 0]
        for alert in self.alerts.values():
            if not alert.ignored:
                defaut[0] += alert.covered
                defaut[1] += 1
                if alert.kind == PastisVulnKind.VULNERABILITY:
                    vulns[0] += alert.validated
                    vulns[1] += 1
        return AlertStat(defaut[0], defaut[1]), AlertStat(vulns[0], vulns[1])

    def write_csv(self, file: Path) -> None:
        with open(file, 'w', newline='') as csvfile:
            fieldnames = ['id', 'kid', 'category', 'kind', 'covered', 'validated']
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            for a in self.counted_alerts:
                writer.writerow({'id': a.id,
                                 'kid': a.kid,
                                 'category': a.category.name,
                                 'kind': a.kind.name,
                                 'covered': a.covered,
                                 'validated': a.validated})

    def show_pastis_stats(self) -> None:
        """
        Show the progress of the analysis by printing alerts
        covered/validated for each PASTIS vulnerability
        categories.

        :return: None
        """
        g_stat = [0, 0, 0, 0]
        for cat, alerts, in self.alerts_by_category().items():
            stat = [0, 0, 0, 0]
            for a in alerts:
                if a.kind == PastisVulnKind.DEFAULT:
                    stat[0] += a.covered
                    stat[1] += 1
                else:
                    stat[2] += a.validated
                    stat[3] += 1
            g_stat[0] += stat[0]
            g_stat[1] += stat[1]
            g_stat[2] += stat[2]
            g_stat[3] += stat[3]
            print("{}: D:{}/{} V:{}/{}".format(cat.name, stat[0], stat[1], stat[2], stat[3]))
        print("Total: D:{}/{} V:{}/{}".format(g_stat[0], g_stat[1], g_stat[2], g_stat[3]))
