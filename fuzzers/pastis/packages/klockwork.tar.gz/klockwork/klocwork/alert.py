from builtins import property
from pathlib import Path
from klocwork.utils import PastisVulnKind, PastisVulnCategory, KlocworkAlertType


class KlocworkAlert:
    """
    Class of data representing a Klocwork alert along with
    attributes to better described it in accordance with the
    PASTIS project. It also defines attributes `covered` and
    `validated` that can be changed by the program.
    """
    def __init__(self):
        # Static alert data
        self.kid = None        # Klocwork ID
        self.code = None       # Klocwork alert code SV.UNBOUND.COPY, UFM.DEREF ..
        self.params = None     # Parameters of the alert (values between parentheses in the report)
        self.taxonomy = None   # Taxonomy used in the report 'C, C++', 'MISRA Checker Package'..
        self.severity = None   # Severity of the report: Review, Error, Critical ..
        self.file = None       # Source file impacted
        self.line = None       # line of code (in the file
        self.function = None   # Function impacted
        self.raw_line = None   # Raw line as shown in report

        # PASTIS binding data
        self.has_pastis_binding = False
        self.id = None
        self.category = None  # PastisVulnType: BUFFER_OVERFLOW, INTEGER_OVERFLOW ..
        self.kind = None      # PastisVulnKind: DEFAULT, VULNERABILITY

        # Analysis results
        self._covered = False
        self._validated = False
        self._uncoverable = False

    def is_alert_type_supported(self):
        return not(isinstance(self.code, str))

    @property
    def covered(self) -> bool:
        """ Returns whether the alert as been covered (a path led to it) """
        return self._covered

    @covered.setter
    def covered(self, val) -> None:
        """ Set an Alert as covered. If it is a 'defaut' also set it as
            validated """
        self._covered = val
        if self.kind == PastisVulnKind.DEFAULT and val:
            self._validated = True

    @property
    def validated(self):
        return self._validated

    @validated.setter
    def validated(self, val):
        self._validated = val

    @property
    def uncoverable(self):
        return self._uncoverable

    @uncoverable.setter
    def uncoverable(self, val: bool) -> None:
        self._uncoverable = val

    @property
    def ignored(self) -> bool:
        """
        Define if the alert is ignored in the context of PASTIS.
        By default they are all ignore except if a "pastis binding"
        has been provided to change it.

        :return: True if the alert is ignored
        """
        return not self.has_pastis_binding

    @staticmethod
    def from_json(data: dict) -> 'KlocworkAlert':
        """
        Create a KlocworkAlert object from the JSON data provided.

        :param data: JSON data of the alert
        :return: KlocworkAlert instance, initialized with the JSON
        """
        alert = KlocworkAlert()
        for name in ["kid", "params", "taxonomy", "severity", "file", "line", "function", "raw_line"]:
            setattr(alert, name, data[name])
        try:
            alert.code = KlocworkAlertType[data['code']]
        except KeyError:
            alert.code = data['code']
        if "pastis_binding" in data:
            alert.parse_pastis_binding(data["pastis_binding"])
        if "pastis_results" in data:
            alert.covered = data["pastis_results"].get("covered", False)
            alert.validated = data["pastis_results"].get("validated", False)
            alert.uncoverable = data["pastis_results"].get("uncoverable", False)
        return alert

    def parse_pastis_binding(self, data: dict) -> None:
        """
        Add pastis contextual information about this alert.

        :param data: pastis binding JSON data for that alert
        :return: None
        """
        self.has_pastis_binding = True
        self.id = data["id"]
        self.category = PastisVulnCategory[data['category']]
        self.kind = PastisVulnKind[data['kind']]

    def to_json(self) -> dict:
        """
        Export the alert attribute to a valid JSON dictionnary
        that can be written to file.

        :return: JSON dict of the alert serialized
        """
        res = {}
        for name in ["kid", "params", "taxonomy", "severity", "file", "line", "function", "raw_line"]:
            res[name] = getattr(self, name)
        res["code"] = self.code if isinstance(self.code, str) else self.code.name
        if self.has_pastis_binding:
            res["pastis_binding"] = {"id": self.id, "category": self.category.name, "kind": self.kind.name}
            res["pastis_results"] = {"covered": self.covered, "validated": self.validated, "uncoverable": self.uncoverable}
        return res

    def __repr__(self):
        return f"<Alert kid:#{self.kid}[{self.id if self.id else '-'}]: {self.code} {self.function}:{self.line} ({Path(self.file).name})>"
