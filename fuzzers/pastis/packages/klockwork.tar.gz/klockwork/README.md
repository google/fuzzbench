# p2_klocwork

Project d'interfaçage avec Klocwork.


# Alertes

Toutes les alertes pouvant être levées par Klocwork sont définies dans la documentation: https://docs.roguewave.com/en/klocwork/current/sv.strbo.unbound_copy

# Objectif

1. Parser le HTML (ou XML ?) pour récupérer les alertes qui nous intéressent
2. A partir du message de chaque alerte générer un assert (ou triton_assert) en l'insérant dans le code source (en mode bourrin)

# Classification des vulnérabilités

![classification vulns](doc/classification_vulns.png)


# Utilisation

L'utilisation de ce module se fait comme suit.

## Installation

Installation du module et des dépendances:

```bash
pip3 install .
```

## Génération/Écriture des rapports

Conversion du rapport HTML klocwork en json

```bash
klocwork-report-to-json.py rapport.html
```

Un fichier ``rapport.json`` devrait être crée.

Le fichier décrivant pour chaque alert si c'est
un défaut, une vulnérabilité et la categorie associée
doit être fait manuellement en fonction des bugs ajoutés
par l'auteur. Ce fichier est dans le code appelé **pastis
binding file**. Le fichier JSON doit être de la forme:

```json
[
  {  
    "kid": 85,
    "id": 1,
    "category": "BUFFER_OVERFLOW",
    "kind": "VULNERABILITY"
  }
]
```

L'attribut ``kid`` et l'identifiant de l'alerte dans le rapport exporté.
``id`` doit être un identifiant unique. L'attribut ``category`` défini
la catégorie de vulnérabilité dans laquelle rentre l'alerte (selon la définition
utilisée dans PASTIS). Enfin ``kind`` défini si l'alerte est un défaut
ou une vulnérabilité (tous ce qui ne déclenche pas de crash/vuln est par
définition un défaut puisque une alerte a été levée). 

## Utilisation

Une fois les deux fichiers générés le module s'utilise de la façon suivante:

```python
from klocwork import KlocworkReport
manager = KlocworkReport("reports/unit4.json", "reports/unit4-binding.json") 
```

ou bien équivalent:

```python
from klocwork import KlocworkReport
manager = KlocworkReport()
manager.parse_file("reports/unit4.json")
manager.parse_alert_binding("reports/unit4-binding.json")
```

Il est ensuite possible de manipuler les objet ``KlocworkAlert`` contenant
toutes les données relative à une alerte. e.g:

```python
manager.alerts_by_file()                                                                                                                                                                                       
{'/home/user/unit4/ce1_buffer_overflow/bof_sample1.c': [<Alert #85: KlocworkAlertType.SV_STRBO_UNBOUND_COPY [Y]>],
 '/home/user/unit4/ce1_buffer_overflow/bof_sample2.c': [<Alert #71: KlocworkAlertType.SV_STRBO_UNBOUND_COPY [Y]>],
 '/home/user/unit4/ce1_buffer_overflow/stack_bo_l1.c': [<Alert #72: KlocworkAlertType.SV_STRBO_UNBOUND_COPY [Y]>],
 '/home/user/unit4/ce3_off_by_one/off_by_one_1.c': [<Alert #78: KlocworkAlertType.ABV_GENERAL [Y]>,
  <Alert #92: KlocworkAlertType.SV_STRBO_BOUND_COPY_OVERFLOW [Y]>],
 '/home/user/unit4/ce3_off_by_one/off_by_one_2.c': [<Alert #87: KlocworkAlertType.SV_STRBO_BOUND_COPY_OVERFLOW [Y]>],
 '/home/user/unit4/ce3_off_by_one/off_by_one_3.c': [<Alert #83: KlocworkAlertType.ABV_GENERAL [Y]>],
 '/home/user/unit4/ce4_use_after_free/use_after_free_1.c': [<Alert #73: KlocworkAlertType.NPD_FUNC_MUST [Y]>,
  <Alert #94: KlocworkAlertType.NPD_FUNC_MUST [Y]>,
  <Alert #91: KlocworkAlertType.UFM_DEREF_MIGHT [Y]>],
 '/home/user/unit4/ce4_use_after_free/use_after_free_2.c': [<Alert #84: KlocworkAlertType.UFM_FFM_MUST [Y]>,
  <Alert #63: KlocworkAlertType.NPD_FUNC_MUST [Y]>,
  <Alert #56: KlocworkAlertType.NPD_FUNC_MUST [Y]>],
 '/home/user/unit4/ce5_format_string/format_string_1.c': [<Alert #80: KlocworkAlertType.SV_TAINTED_FMTSTR [Y]>],
 '/home/user/unit4/ce5_format_string/format_string_2.c': [<Alert #128: KlocworkAlertType.SV_FMTSTR_GENERIC [Y]>,
  <Alert #88: KlocworkAlertType.SV_TAINTED_FMTSTR [Y]>],
 '/home/user/unit4/ce5_format_string/format_string_3.c': [<Alert #54: KlocworkAlertType.SV_TAINTED_FMTSTR [Y]>]}
```

```python
m.show_pastis_stats()                                                                                                                                                                                        
BUFFER_OVERFLOW: D:0/0 V:0/3
OFF_BY_ONE: D:0/0 V:0/4
INVALID_MEMORY_ACCESS: D:0/4 V:0/0
USE_AFTER_FREE: D:0/0 V:0/2
FORMAT_STRING: D:0/0 V:0/4
Total: D:0/4 V:0/13
```

## Insertion d'assertion dans les sources

Le script ``klockwork-alert-inserter.py`` utilise le module `KlocworkAlertManger` pour effectuer
l'ajout d'assertion (de stubs) relatifs à chaque alertes (ce qui permet de les retrouver au niveau binaire).
Le script s'utilise comme suit:

```bash
klocwork-alert-inserter.py unit4.json unit4-binding.json /home/user/work/PASTIS/logic_bomb_test_suite:$PWD/sources
```

Les trois paramètres sont:
* rapport exporté en JSON
* binding pastis des alertes en JSON
* la substitution à effectuer sur les chemins indiqués dans le .json et les sources locales sur la machine
  (car l'analyse Klocwork est faite par la DGA avec un chemin arbitraire)

Le script génère (pour le moment) un fichier ``.cnew`` pour chaque fichier ``.c`` dans lequel une alerte devait
être ajoutée.


## Compilation

Les sources modifiés peuvent être compilés en "linkant" le programme sur ``libpastis.so``. La librairie se
trouve dans `libpastis-intrinsic`. La compilation de la librairie est du programme de test peut être faite comme suit:

```bash
gcc -o libpastis.so pastis.c -shared

gcc -o test test.c -I libpastis-intrinsic/ -L libpastis-intrinsic/ -lpastis
```

Ou statiquement:

```bash
gcc -c pastis.c
ar rcs libpastis.a pastis.o

gcc -o test test.c libpastis-intrinsic/libpastis.a -I libpastis-intrinsic
```


# Exemple complet

Le fichier `bof_sample1.c` contient le code suivant:

```c
#include <stdio.h>
#include <string.h>

int entry(const char *s) {
  int x = 0x12345678;
  char buff[32];

  strcpy(buff, s);

  if (x != 0x12345678)
    return 1;
  else
    return 0;
}

int main(int ac, const char* av[]) {
    char input[1024];
    return entry(av[1]);
}
```

Le rapport `klocwork` convertis en JSON avec ``klocwork-report-to-json.py`` génère le fichier suivant:

```json
[
  {
    "file": "/home/user/work/PASTIS/test/bof_sample1.c",
    "line": 8,
    "function": "entry",
    "code": "SV_BANNED_REQUIRED_COPY",
    "severity": "Review",
    "taxonomy": "C and C++",
    "kid": 81,
    "raw_line": "Function 'strcpy' is deprecated. Replace with more secure equivalent like 'strcpy_s', add missing logic, or re-architect.",
    "params": [
      "strcpy",
      "strcpy_s"
    ]
  },
  {
    "file": "/home/user/work/PASTIS/test/bof_sample1.c",
    "line": 8,
    "function": "entry",
    "code": "SV_STRBO_UNBOUND_COPY",
    "severity": "Critical",
    "taxonomy": "C and C++",
    "kid": 85,
    "raw_line": "function 'strcpy' does not check buffer boundaries but outputs to buffer 'buff' of fixed size (32)",
    "params": [
      "strcpy",
      "buff",
      "32"
    ]
  }
]
```

On écrit le fichier de binding indiquant que seul l'alerte 85 nous intéresse car c'est une ``SV_STRBO_UNBOUND_COPY``.
On lui affecte l'identifiant 1. Le fichier contient donc:

```json
[
  {
    "kid": 85,
    "id": 1,
    "category": "BUFFER_OVERFLOW",
    "kind": "VULNERABILITY"
  }
]
```

On insert l'alerte dans notre code source se trouvant dans le dossier `/home/foo/test` avec la commande:

```bash
klocwork-alert-inserter.py report.json binding.json /home/user/work/PASTIS:/home/foo
```

Le fichier alors généré est:

```c
#include "pastis.h"
#include <stdio.h>
#include <string.h>

int entry(const char *s) {
  int x = 0x12345678;
  char buff[32];

  __klocwork_alert_placeholder(1, "SV_STRBO_UNBOUND_COPY", strlen(s) < 32);
  strcpy(buff, s);

  if (x != 0x12345678)
    return 1;
  else
    return 0;
}

int main(int ac, const char* av[]) {
    char input[1024];
    return entry(av[1]);
}
```

Puis on le compile et l'exécute avec:

```bash
mv bof_sample1.cnew bof_sample1_annot.c
gcc -o bof_sample1 bof_sample1_annot.c libpastis-intrinsic/libpastis.a -I libpastis-intrinsic

./bof_sample1 AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
```
