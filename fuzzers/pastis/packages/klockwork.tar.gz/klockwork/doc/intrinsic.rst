.. _klocwork_intrinsic:

Intrinsic Functions
===================

An intrinsic function is an ad-hoc function added in the source code that will receive
a specific processing from a third-party tool during the execution of the program. As
a foreign function in the code in which it is inserted it should not interfere with the
original code nor changing changing the behavior of the host program. That mecanism is
used in various tools like `KLEE <https://klee.github.io/docs/intrinsics/>`_.

These functions added semi-automatically in the source can play the role of test requirements.
If they all gets covered the test engine might decide the criteria is achieved. One can decide
what action to perform when these functions are reached during execution. Main purpose of
these functions are:

* performing some links between source code and the binary, regardless of whether
  that code portion is inlined, duplicated etc.
* knowing when such code area is reached *(with some printing for instance)*
* performing some checks at runtime by the analyzer *(e.g: some SMT queries with a DSE etc)*

Prototype
---------

This python module enable adding intrinsic functions in the source code based on alerts
data. The code snippet added in the source code is the following:

.. code-block:: c

    #ifdef QB_VULNERABILITY
    int __klocwork_alert_placeholder(int id, const char* fmst, ...){
      printf("REACHED ID %d\n", id);
      return id;
    }
    #endif

This function takes the alert identifier given by the klocwork report or the binding
of the user (cf. :ref:`binding_section`). Then it takes the vulnerability type as
defined by Klocwork, *(e.g: ``ABV.GENERAL``)*. That function being variadic it then
provides a number of contextual information extracted from the report. That allows
retrieving some pointers or sizes as parameter of the function *(that is particularly
helpfull for the DSE)*. These parameters depends on the alert type.

.. note:: In the context of the PASTIS project, these functions are solely added on Klocwork
  alerts but one can decide to add some manually in any code location and for any purpose.
  Indeed, these functions are mostly markers and can be used in any manner.


Inserting intrinsics
--------------------

This module provides the utility :program:`klocwork-alert-inserter` allowing to add
automatically the intrinsic functions in files and lines given by the report.
The insertion is **purely syntactical** and does not consider program semantic.
As such, it might break the program logic. **It thus have to be checked manually !**
Depending on the alert type the intrinsic function is added before or after the ligne
of code pinpointed. The exemple below shows an exemple of how to use the utility.


.. highlight:: none

::

    klocwork-alert-inserter report-binded.json /home/user/work/PASTIS/programme_etalon_v4/:/home/robin/cyclonetcp_harness

The only peculiarity here is that paths given by the report are specific the the machine
used to perform the analysis and not sources locally. The user should provide the path prefix
substitution to use separated by ":". The result of executing that program is the addition
of a call to the intrinsic function on all alerts given by the binding of the report *(that
should be inside `report-binded.json`)*

.. warning:: As mentioned insertion of intrinsic functions is not perfect. For instance
  the insertion consider that the function is defined globally thus visible from the scope
  where it is added. No include is being added. Moreover, insertion is made line by line
  in a syntactical manner without consider program semantic. As such, added rigth after a
  'if' without parentheses will break program semantic. **The result should always be checked
  manually.**

.. todo:: To move it to the next level, we could have used the LLVM API for clang to
  manipulate the C AST. That has not been done by lack of time and is left as future
  work.
