Klocwork documentation
======================

This module provides a simple API wrapping a Klocwork report allowing
manipulating it. Its main purpose is to convert a Klocwork report from HTML
to JSON and then Python classes to manipulate a report and alerts.

.. warning::

    This module is solely useful if you have been able to obtain a Klocwork
    report for the sources you want to audit.

Based on the report for the sources to audit, this module also provide
a very basic utility to insert intrinsic functions in the code source
at locations indicated by the report. That enable retrieving these
location during the fuzzing session to implement any behavior on these
functions.


.. toctree::
   :caption: Getting started
   :maxdepth: 2

    Installation <installation>
    Report & Binding <report>
    Intrinsic insertion <intrinsic>

.. toctree::
    :caption: Python API
    :maxdepth: 3

    api


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
