Klocwork Installation
=====================

Klocwork is a pure Python module and all dependencies can be installed from pip.
Its main dependency is `lxml <https://lxml.de>`_ that it uses for parsing the HTML into JSON.

.. code-block:: bash

    $ cd klocwork
    $ pip3 install .
