.. _klocwork_report:

Klocwork Report
===============

A Klocwork report is a HTML document containing a table describing each alerts
raised with some contextual data from the analyzer. To use a report data have
to be extracted in a processable format. This is especially useful to automatically
add intrinsic functions in the source code (see. :ref:`klocwork_intrinsic`). The
image below shows what a report looks like in HTML.

.. figure:: figs/klreport.png
   :scale: 100 %
   :align: center
   :alt: Sample report in HTML

This python module, allows converting the report in JSON using `lxml <https://lxml.de>`_.
The file is converted in JSON as a list of alerts. Each alerts is a dictionnary holding
all data extracted from the HTML. The exemple hereafter gives an example of such alert.

.. code-block:: JSON

    {
      "kid": 5139,
      "params": ["datagram", "netBufferAt", "431", "434"],
      "taxonomy": "C and C++",
      "severity": "Critical",
      "file": "/home/user/[...]/cyclone_tcp/cyclone_tcp/ipv4/ipv4_frag.c",
      "line": 434,
      "function": "ipv4ReassembleDatagram",
      "raw_line": "Pointer 'datagram' returned from call to function 'netBufferAt' at line 431 may be NULL and will be dereferenced at line 434.",
      "code": "NPD_FUNC_MUST"
    }


Converting a report
-------------------

This module provides the utility :program:`klocwork-report-to-json` converting
a report to JSON. It also enables providing a binding to filter a subset of alerts
to consider *(All of them will be present in the JSON but only the subset will be
considered by :py:class:`klocwork.KlocworkReport`)*. The listing shows all the options
of the utility. If no output file is provided, the resulting name will be the input
name but with its extension substituted.

.. highlight:: none

::

    Usage: klocwork-report-to-json [OPTIONS] REPORT

    Options:
      -b, --binding FILE  Binding file
      -o, --out PATH      Output JSON report file
      --help              Show this message and exit.


.. _binding_section:

Binding
-------

A so-called binding file was created in the context of the PASTIS project to categorize
alerts in some vulnerability families *(buffer overflow, Use-After-Free ..)* and also to
indicate if the alert is a false positive *(a "default")* or a true vulnerability where
some inputs can trigger the vulnerability. We know that in advance if code constructs
yielding these alerts have been purposely inserted in the code *(which is the case for
PASTIS)*.

As such, a binding file defines alerts to consider withing the large amount of alerts
yielded by Klocwork. Writing a binding have to be done manually when knowing the ground
truth. If not the method :py:meth:`klocwork.KlocworkReport.auto_bind` enables considering
automatically all supported alerts. Supported alerts are defined in :py:class:`klocwork.KlocworkAlertType`.
A binding also enables providing user-defined `ids` to each alert considered. A binding
is a JSON file organised as a list of entries as shown below.

.. code-block:: JSON

    {
        "kid": 85,
        "id": 1,
        "category": "BUFFER_OVERFLOW",
        "kind": "VULNERABILITY"
    }

The attribute `kid` is the identifier of the alert contained in the klocwork report, `id` is the
user-defined identifier *(for its own purpose)*. It can be anything but must be unique. Then
`category` and `kind` indicates repsectively the category of the vulnerability and whether its
a "default" or a "vulnerability". The command shown below shows how to convert a report in JSON
and embedding in it a binding.

::

    klocwork-report-to-json report.html -b binding.json -o report-binded.json

