#ifndef PASTIS_CRT_H
#define PASTIS_CRT_H

extern int __klocwork_alert_placeholder(int id, const char* fmst, ...);

#endif
