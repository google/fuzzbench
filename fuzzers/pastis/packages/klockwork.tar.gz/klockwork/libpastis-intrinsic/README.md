# libpastis-intrinsic

This library is an example of how can intrinsic functions be inserted.
There is two ways of inserting intrinsics:

* Copying the intrinsic function in your source tree
* Linking against this library

We strongly recommend copying this intrinsic function in you source tree
(and to keep symbols to make sure it can be found in the resulting binary).
If linking against the library, once again we strongly recommend linking
against statically. Otherwise the resulting executable would depend on the
.so which is not necessarily a desired behavior.
