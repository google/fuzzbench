#include "pastis.h"

int __klocwork_alert_placeholder(int id, const char* fmst, ...) {
    // do nothing, we return id only to force the compiler to not optimize this function.
    //printf("PASTIS: vuln id %d, type %s\n", id, fmst);
    return id;
}
