#!/bin/sh
./bin/pastis-broker workspace ./workspace/unit4.json ../programme_etalon_final/micro_http_server wlp0s20f3 48:e2:44:f5:9b:01 10.0.13.86 255.255.255.0 10.0.13.254
