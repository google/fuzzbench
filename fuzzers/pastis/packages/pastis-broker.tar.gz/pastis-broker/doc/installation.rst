Broker Installation
===================

Pastis-broker relies on ``libpastis`` and ``klocwork`` as PASTIS dependencies.
Apart from that all dependencies can be install through pip. It is not dependent
on neither ``honggfuzz`` nor ``triton``. After having installed the two aforementioned
dependencies, just do:

.. code-block:: bash

    $ cd pastis-broker
    $ pip3 install .
