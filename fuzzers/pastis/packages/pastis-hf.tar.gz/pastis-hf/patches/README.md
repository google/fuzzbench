# README

Here you'll find the patch files for the modifications introduce to Honggfuzz
to support Pastis.

## Instructions

To build a working Honggfuzz version with the patch run the following command:

```bash
sudo apt-get install binutils-dev libunwind-dev libblocksruntime-dev clang

./make_hf.sh
```
