# pastisd

Pastis daemon that will be running on the embedded device.

Its main task is to connect to the broker advertisizing all the engines installed locally.
The broker then decide which engine to start, and the pastisd will start the appropriate one.
