.. _pastisaflpp_api_usage:

Pastis-AFLPP API
----------------

.. toctree::
    :caption: Python API
    :maxdepth: 3

    AFLPP <api/pastisaflpp>
    Replay <api/replay>
