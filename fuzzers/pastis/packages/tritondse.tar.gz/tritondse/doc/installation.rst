TritonDSE Installation
======================

Now that Triton is available through Pypi, all TritonDSE dependencies can be installed via pip.
Installing is as simple as:

.. code-block:: bash

    $ cd tritondse
    $ pip3 install .

.. note:: As of the version 0.11 of LIEF, it can be installed in the same manner on an ARM, Aarch64
          Linux as it now chip a version of LIEF for that architecture. *(otherwise requires to be
          installed manually by compiling it)*.
