Crackme
=======

The following sections are a bunch of crackme challenges to solve using TritonDSE.


Hackcon-2016-angry-reverser
---------------------------

.. raw:: html

    <div style="text-align: center;"><a href="../../../_static/yolomolo"><i class="fa fa-download fa-lg"></i><br/>binary</a></div><br/>


Hackover-ctf-2015-r150
----------------------


.. raw:: html

    <div style="text-align: center;"><a href="../../../_static/rvs.bin"><i class="fa fa-download fa-lg"></i><br/>binary</a></div><br/>

