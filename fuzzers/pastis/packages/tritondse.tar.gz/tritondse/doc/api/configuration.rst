.. _label_configuration:

Configuration
=============

.. autoclass:: tritondse.Config
    :members:
    :undoc-members:
    :exclude-members:

