Supported Routines
==================

Linux
-----

.. automodule:: tritondse.routines
    :members:
    :show-inheritance:
    :inherited-members:
    :undoc-members:
    :exclude-members:


Windows
-------

.. todo:: **tritondse** does not support Windows and thus
          none of its API functions.