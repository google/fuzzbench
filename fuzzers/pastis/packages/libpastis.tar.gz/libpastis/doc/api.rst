libpastis API
-------------

.. toctree::
    :maxdepth: 2

    api/agent
    api/types
