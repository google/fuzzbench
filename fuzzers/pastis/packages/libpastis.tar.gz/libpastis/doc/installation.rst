
libpastis installation
----------------------

Libpastis can be installed through pip:

.. code-block:: bash

    $ cd libpastis
    $ pip3 install .
