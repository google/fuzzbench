from .message_pb2 import *

SeedType = InputSeedMsg.SeedType
Arch = HelloMsg.Arch
