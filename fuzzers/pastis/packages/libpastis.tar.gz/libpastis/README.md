# libpastis-comm

Message Queuing based library for components to interact with each other.


# Installation

TODO


# Running as a Broker

TODO

# Running as a client

TODO